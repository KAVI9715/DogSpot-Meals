
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import type { Product } from '@/services/product-service';
import { createProduct, updateProduct } from '@/services/product-service';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { productCategories } from '@/lib/data';

const formSchema = z.object({
  name: z.string().min(3, "Product name must be at least 3 characters long."),
  price: z.coerce.number().positive("Price must be a positive number."),
  category: z.enum(['Small', 'Medium', 'Indie Special', 'Large', 'Giant', 'Trial']),
  description: z.string().min(20, "Description must be at least 20 characters long."),
  image1: z.string().url("Please enter a valid image URL."),
  image2: z.string().url("Please enter a valid image URL."),
  image1Hint: z.string().optional(),
  image2Hint: z.string().optional(),
  feedingGuideImage: z.string().url("Please enter a valid image URL.").optional().or(z.literal('')),
});

type ProductFormValues = z.infer<typeof formSchema>;

interface ProductFormProps {
  product?: Product;
}

export function ProductForm({ product }: ProductFormProps) {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const router = useRouter();

  const form = useForm<ProductFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: product || {
      name: '',
      price: 0,
      category: 'Trial',
      description: '',
      image1: '',
      image2: '',
      image1Hint: '',
      image2Hint: '',
      feedingGuideImage: '',
    },
  });

  const onSubmit = async (data: ProductFormValues) => {
    setLoading(true);
    try {
        if (product) {
            // Update existing product
            await updateProduct(product.id, data);
            toast({
                title: 'Product Updated!',
                description: `"${data.name}" has been successfully updated.`,
            });
        } else {
            // Create new product
            await createProduct(data);
            toast({
                title: 'Product Created!',
                description: `"${data.name}" has been successfully added to your store.`,
            });
        }
        router.push('/admin/products');
        router.refresh(); // Refresh server components
    } catch (error) {
        console.error('Failed to save product:', error);
        toast({
            title: 'An error occurred.',
            description: 'Failed to save product. Please try again.',
            variant: 'destructive',
        });
    } finally {
        setLoading(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Card>
          <CardHeader>
            <CardTitle>{product ? 'Edit Product' : 'New Product Details'}</CardTitle>
            <CardDescription>Fill in the details below. All fields are required unless marked optional.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Product Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Chicken and Rice Meal" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid md:grid-cols-2 gap-6">
                <FormField
                control={form.control}
                name="price"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Price (INR)</FormLabel>
                    <FormControl>
                        <Input type="number" placeholder="e.g., 1499.00" {...field} />
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
                />
                <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Category</FormLabel>
                     <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                            <SelectTrigger>
                                <SelectValue placeholder="Select a category" />
                            </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                            {productCategories.map(cat => (
                                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                            ))}
                             <SelectItem value="Trial">Trial</SelectItem>
                        </SelectContent>
                    </Select>
                    <FormMessage />
                    </FormItem>
                )}
                />
            </div>
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Detailed product description (HTML is supported)..." {...field} rows={8} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid md:grid-cols-2 gap-6">
                <FormField
                control={form.control}
                name="image1"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Primary Image URL</FormLabel>
                    <FormControl>
                        <Input placeholder="https://..." {...field} />
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
                />
                <FormField
                control={form.control}
                name="image2"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Secondary Image URL</FormLabel>
                    <FormControl>
                        <Input placeholder="https://..." {...field} />
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
                />
            </div>
             <div className="grid md:grid-cols-2 gap-6">
                <FormField
                control={form.control}
                name="image1Hint"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Primary Image AI Hint</FormLabel>
                    <FormControl>
                        <Input placeholder="e.g., 'dog food'" {...field} />
                    </FormControl>
                    <FormDescription>Optional. One or two keywords for AI.</FormDescription>
                    <FormMessage />
                    </FormItem>
                )}
                />
                <FormField
                control={form.control}
                name="image2Hint"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Secondary Image AI Hint</FormLabel>
                    <FormControl>
                         <Input placeholder="e.g., 'dog meal'" {...field} />
                    </FormControl>
                     <FormDescription>Optional. One or two keywords for AI.</FormDescription>
                    <FormMessage />
                    </FormItem>
                )}
                />
            </div>
             <FormField
              control={form.control}
              name="feedingGuideImage"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Feeding Guide Image URL (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="https://..." {...field} />
                  </FormControl>
                  <FormDescription>Optional. URL for the feeding guide image.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
          <CardFooter className="flex justify-end gap-2">
            <Button variant="outline" type="button" onClick={() => router.back()}>Cancel</Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {product ? 'Save Changes' : 'Create Product'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </Form>
  );
}
