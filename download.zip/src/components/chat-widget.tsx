
'use client';

import { useState, useRef, useEffect, useTransition } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { MessageCircle, Send, X, Bot, User, HelpCircle } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { chat } from '@/ai/flows/chat-flow';
import type { ChatInput } from '@/ai/schemas/chat-schemas';
import { cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';

type Message = {
  role: 'user' | 'model';
  content: string;
};

declare global {
    interface Window {
        google: {
            studio: {
                RequestFirebaseProjectWithConfig: () => Promise<void>;
            }
        }
    }
}

export function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isPending, startTransition] = useTransition();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const isFirebaseConnected = process.env.NEXT_PUBLIC_FIREBASE_API_KEY && process.env.NEXT_PUBLIC_FIREBASE_API_KEY !== 'YOUR_API_KEY';
       if (!isFirebaseConnected) {
         setMessages([
            { role: 'model', content: 'Welcome! It looks like your Firebase project is not connected. Would you like me to help you connect it?' }
         ]);
       } else {
         setMessages([{ role: 'model', content: 'Hello! How can I help you today? Your Firebase project is connected. You can manage products, orders, and site content in the admin panel.' }]);
       }
    }
  }, [isOpen, messages.length]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleFirebaseConnect = async () => {
    setMessages(prev => [...prev, { role: 'model', content: "Great! I'm now creating a Firebase project for you. This might take a moment..."}]);
    try {
        if (window.google?.studio?.RequestFirebaseProjectWithConfig) {
            await window.google.studio.RequestFirebaseProjectWithConfig();
            setMessages(prev => [...prev, { role: 'model', content: "Success! Your Firebase project is connected. You can now use features like the admin panel. What would you like to do next?"}]);
        } else {
            throw new Error("Firebase connection function not available.");
        }
    } catch (error) {
        console.error("Firebase connection error: ", error);
        setMessages(prev => [...prev, { role: 'model', content: "I encountered an error while trying to connect to Firebase. Please try again or check your project settings."}]);
    }
  }


  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const newMessages: Message[] = [...messages, { role: 'user', content: input }];
    setMessages(newMessages);
    const userInput = input;
    setInput('');
    
    startTransition(async () => {
        const lowercasedInput = userInput.trim().toLowerCase();
        const isFirebaseConnected = process.env.NEXT_PUBLIC_FIREBASE_API_KEY && process.env.NEXT_PUBLIC_FIREBASE_API_KEY !== 'YOUR_API_KEY';

        if (!isFirebaseConnected && (lowercasedInput.includes('yes') || lowercasedInput.includes('connect')) && messages.some(m => m.content.includes('connect'))) {
            await handleFirebaseConnect();
            return;
        }

        try {
            const chatInput: ChatInput = {
              history: newMessages.slice(0, -1).map(msg => ({ role: msg.role, content: msg.content })),
              newMessage: userInput,
            };
            const result = await chat(chatInput);
            setMessages(prev => [...prev, { role: 'model', content: result.response }]);
        } catch (error) {
            console.error('Error fetching AI response:', error);
            setMessages(prev => [...prev, { role: 'model', content: "Sorry, I'm having trouble connecting. Please try again later." }]);
        }
    });
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {isOpen ? (
        <Card className="w-80 md:w-96 h-[60vh] flex flex-col shadow-2xl rounded-xl">
          <CardHeader className="flex flex-row items-center justify-between p-4 bg-primary text-primary-foreground rounded-t-xl">
            <CardTitle className="text-base font-semibold">Chat with us!</CardTitle>
            <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="text-primary-foreground hover:bg-primary/80">
              <X className="h-5 w-5" />
            </Button>
          </CardHeader>
          <CardContent className="flex-1 p-4 overflow-y-auto bg-background/80">
            <div className="flex flex-col gap-4">
              {messages.map((message, index) => (
                <div key={index} className={cn("flex items-start gap-3", message.role === 'user' ? 'justify-end' : 'justify-start')}>
                  {message.role === 'model' && (
                    <Avatar className="h-8 w-8">
                       <AvatarFallback className="bg-primary text-primary-foreground"><Bot className="h-5 w-5" /></AvatarFallback>
                    </Avatar>
                  )}
                  <div className={cn("p-3 rounded-lg max-w-[85%]", message.role === 'model' ? 'bg-muted text-muted-foreground' : 'bg-primary text-primary-foreground')}>
                    <p>{message.content}</p>
                  </div>
                   {message.role === 'user' && (
                    <Avatar className="h-8 w-8">
                       <AvatarFallback className="bg-secondary text-secondary-foreground"><User className="h-5 w-5" /></AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))}
               {isPending && (
                <div className="flex items-start gap-3 justify-start">
                   <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-primary text-primary-foreground"><Bot className="h-5 w-5" /></AvatarFallback>
                   </Avatar>
                  <Skeleton className="w-3/4 h-12 rounded-lg" />
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </CardContent>
          <CardFooter className="p-4 border-t bg-background">
            <form onSubmit={handleSendMessage} className="flex w-full items-center gap-2">
              <Input
                placeholder="Type a message..."
                className="flex-1"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                disabled={isPending}
              />
              <Button type="submit" disabled={isPending || !input.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </CardFooter>
        </Card>
      ) : (
        <Button
          onClick={() => setIsOpen(true)}
          className="rounded-full h-16 w-16 shadow-lg flex items-center justify-center bg-primary hover:bg-primary/90"
          aria-label="Open chat window"
        >
          <HelpCircle className="h-8 w-8 text-primary-foreground" />
        </Button>
      )}
    </div>
  );
}
