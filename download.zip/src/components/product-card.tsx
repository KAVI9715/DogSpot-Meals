
'use client';
import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import type { Product } from '@/services/product-service';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  const formatPrice = (price: number) => {
    return price.toLocaleString('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
  };

  const buttonText = product.name.includes('Small Breed') || product.name.includes('XS Breed')
    ? 'Buy'
    : 'View Product';

  return (
    <Card 
      className="overflow-hidden group transition-all duration-300 hover:shadow-xl flex flex-col h-full"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
        <Link href={`/products/${product.id}`} className='flex flex-col h-full'>
      <CardContent className="p-0 flex flex-col flex-grow">
        <div className="relative aspect-square">
            <Image
              src={product.image1}
              alt={product.name}
              fill
              data-ai-hint={product.image1Hint}
              className={cn(
                "object-cover transition-opacity duration-500 ease-in-out",
                isHovered ? 'opacity-0' : 'opacity-100'
              )}
            />
            <Image
              src={product.image2}
              alt={`${product.name} alternate view`}
              fill
              data-ai-hint={product.image2Hint}
              className={cn(
                "object-cover transition-opacity duration-500 ease-in-out",
                isHovered ? 'opacity-100' : 'opacity-0'
              )}
            />
        </div>
        <div className="p-4 space-y-2 text-center flex flex-col items-center justify-between flex-grow">
          <h3 className="font-semibold text-base flex-grow flex items-center">{product.name}</h3>
          <div className="space-y-2">
            <p className="font-bold text-lg">{formatPrice(product.price)}</p>
            <Button className="opacity-0 group-hover:opacity-100 transition-opacity" variant="secondary">
              <div>{buttonText}</div>
            </Button>
          </div>
        </div>
      </CardContent>
        </Link>
    </Card>
  );
}
