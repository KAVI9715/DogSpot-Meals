import Link from 'next/link';
import { PawPrint, Facebook, Twitter, Instagram, Youtube, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export function Footer() {
  return (
    <footer className="bg-secondary/50 border-t">
      <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2 font-bold text-xl font-headline">
              <PawPrint className="h-7 w-7 text-primary" />
              DogSpot Delights
            </Link>
            <form className="flex gap-2">
              <Input type="search" placeholder="Search..." className="flex-1 bg-background" />
              <Button type="submit" variant="outline" size="icon" aria-label="Search">
                <Search className="h-5 w-5" />
              </Button>
            </form>
            <div className="flex space-x-4">
              <Link href="https://www.facebook.com/indogspot" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors"><span className="sr-only">Facebook</span><Facebook /></Link>
              <Link href="https://www.instagram.com/indogspot/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors"><span className="sr-only">Instagram</span><Instagram /></Link>
              <Link href="https://www.youtube.com/indogspot" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors"><span className="sr-only">Youtube</span><Youtube /></Link>
              <Link href="https://x.com/indogspot" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors"><span className="sr-only">Twitter</span><Twitter /></Link>
            </div>
          </div>

          <div className="md:justify-self-center">
            <h3 className="text-lg font-semibold tracking-wider uppercase">Quick Links</h3>
            <ul className="mt-4 space-y-2">
              <li><Link href="/privacy-policy" className="text-muted-foreground hover:text-primary transition-colors">Privacy policy</Link></li>
              <li><Link href="/return-policy" className="text-muted-foreground hover:text-primary transition-colors">Return & Refund Policy</Link></li>
              <li><Link href="/shipping-policy" className="text-muted-foreground hover:text-primary transition-colors">Shipping Policy</Link></li>
              <li><Link href="/terms-of-service" className="text-muted-foreground hover:text-primary transition-colors">Terms of Service</Link></li>
              <li><Link href="/return-policy" className="text-muted-foreground hover:text-primary transition-colors">Refund policy</Link></li>
            </ul>
          </div>
          
          <div>
            {/* Third column left blank as per design interpretation */}
          </div>

        </div>

        <div className="mt-12 border-t border-border pt-8 text-center text-sm text-muted-foreground">
          <p>
            © 2025,{' '}
            <Link href="/" className="hover:text-primary hover:underline transition-colors">DogSpot Meals</Link>{' '}
            <a 
              href="https://www.shopify.com/in?utm_campaign=poweredby&utm_medium=shopify&utm_source=onlinestore" 
              target="_blank" 
              rel="noopener noreferrer"
              className="hover:text-primary hover:underline transition-colors"
            >
              Powered by Shopify
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
