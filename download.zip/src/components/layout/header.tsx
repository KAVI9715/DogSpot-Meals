
'use client';

import Link from 'next/link';
import { Menu, PawPrint, Search, User, ShoppingCart, MoreVertical, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger, SheetClose } from '@/components/ui/sheet';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { useState, useEffect } from 'react';
import { useCart } from '@/hooks/use-cart';
import { useAuth, auth } from '@/hooks/use-auth';
import { signOut } from 'firebase/auth';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';

const navLinks = [
  { href: '/', label: 'Home' },
  { href: '/products', label: 'Products' },
  { href: '/about', label: 'About Us' },
  { href: '/blog', label: 'Blog' },
  { href: '/get-in-touch', label: 'Get in Touch' },
  { href: '/rewards', label: 'Rewards' },
];

export function Header() {
  const pathname = usePathname();
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const { items } = useCart();
  const [isMounted, setIsMounted] = useState(false);
  const { user, loading } = useAuth();
  const router = useRouter();
  const { toast } = useToast();

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const totalItems = isMounted ? items.reduce((total, item) => total + item.quantity, 0) : 0;

  const handleLogout = async () => {
    try {
      if (!auth) return;
      await signOut(auth);
      toast({ title: 'Logged Out', description: 'You have been successfully logged out.' });
      router.push('/');
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to log out.', variant: 'destructive' });
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 max-w-screen-2xl items-center justify-between">
        <Link href="/" className="flex items-center gap-2 font-bold" prefetch={false}>
          <PawPrint className="h-6 w-6 text-primary" />
          <span className="hidden font-headline sm:inline">DogSpot Delights</span>
        </Link>

        <nav className="hidden lg:flex gap-6 text-sm font-medium">
          {navLinks.map(({ href, label }) => (
            <Link
              key={href}
              href={href}
              className={cn(
                'transition-colors hover:text-primary',
                pathname === href ? 'text-primary' : 'text-foreground/60'
              )}
              prefetch={false}
            >
              {label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="hidden md:inline-flex">
            <Search className="h-5 w-5" />
            <span className="sr-only">Search</span>
          </Button>

          {!loading && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="hidden md:inline-flex">
                  <User className="h-5 w-5" />
                  <span className="sr-only">User Menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {user ? (
                  <>
                    <DropdownMenuLabel>{user.email}</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => router.push('/account')}>
                      <User className="mr-2 h-4 w-4" />
                      <span>My Account</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Logout</span>
                    </DropdownMenuItem>
                  </>
                ) : (
                  <>
                    <DropdownMenuItem onClick={() => router.push('/login')}>
                      <span>Login</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => router.push('/register')}>
                      <span>Register</span>
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          )}

          <Button variant="ghost" size="icon" className="relative hidden md:inline-flex" asChild>
            <Link href="/cart">
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                 <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                    {totalItems}
                 </span>
              )}
              <span className="sr-only">Cart</span>
            </Link>
          </Button>
           <Button variant="ghost" size="icon" className="hidden md:inline-flex">
            <MoreVertical className="h-5 w-5" />
            <span className="sr-only">More</span>
          </Button>

          <div className="lg:hidden">
            <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">Toggle navigation menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <div className="flex flex-col gap-6 p-6">
                  <Link href="/" className="flex items-center gap-2 font-bold" onClick={() => setIsSheetOpen(false)}>
                    <PawPrint className="h-6 w-6 text-primary" />
                    <span className="font-headline">DogSpot Delights</span>
                  </Link>
                  <nav className="grid gap-4 text-lg">
                    {navLinks.map(({ href, label }) => (
                       <SheetClose asChild key={href}>
                          <Link
                            href={href}
                            className={cn(
                              'transition-colors hover:text-primary',
                              pathname === href ? 'text-primary' : 'text-foreground/80'
                            )}
                            prefetch={false}
                          >
                            {label}
                          </Link>
                       </SheetClose>
                    ))}
                  </nav>
                   <div className="mt-4 flex items-center gap-4">
                     <Button variant="ghost" size="icon" asChild>
                        <Link href="/cart">
                           <ShoppingCart className="h-6 w-6" />
                           <span className="sr-only">Cart</span>
                        </Link>
                     </Button>
                      {totalItems > 0 && (
                        <span className="text-sm text-muted-foreground">{totalItems} item(s) in cart</span>
                      )}
                   </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
