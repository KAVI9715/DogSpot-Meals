'use client';

import { Star } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

function ReviewCard({ review, index }: { review: string; index: number }) {
  // Simple hashing for unique avatar generation
  const avatarNumber = (index % 10) + 1;
  const name = `Pawsitive Pet Parent #${avatarNumber}`;
  const initials = name.split(' ').map(n => n[0]).join('');

  return (
    <Card className="h-full">
      <CardHeader>
        <div className="flex items-center gap-4">
          <Avatar>
            <AvatarImage src={`https://picsum.photos/40/40?random=${25 + avatarNumber}`} data-ai-hint="person avatar" />
            <AvatarFallback>{initials}</AvatarFallback>
          </Avatar>
          <div>
            <CardTitle className="text-base">{name}</CardTitle>
            <div className="flex text-primary">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-4 w-4 fill-current" />
              ))}
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground">"{review}"</p>
      </CardContent>
    </Card>
  );
}

interface CustomerFeedbackProps {
  reviews: string[];
}

export function CustomerFeedback({ reviews }: CustomerFeedbackProps) {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center space-y-4">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl font-headline">Happy Pups, Happy Parents</h2>
          <p className="max-w-[700px] mx-auto text-muted-foreground md:text-xl">
            Don't just take our word for it. Here's what our community is saying about DogSpot Meals.
          </p>
        </div>
        <div className="mx-auto grid max-w-5xl items-start gap-8 sm:grid-cols-2 md:gap-12 lg:max-w-none lg:grid-cols-3 xl:grid-cols-4 mt-12">
          {reviews.map((review, index) => (
            <ReviewCard key={index} review={review} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
