

'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { Button } from '@/components/ui/button';
import { ProductCard } from '@/components/product-card';
import type { SlideshowImage, CollectionImage, FeaturedRecipe, MulticolumnItem } from '@/services/site-content-service';
import type { Product } from '@/services/product-service';
import { CustomerFeedback } from '@/components/customer-feedback';
import { ArrowRight } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { useRef } from 'react';
import Autoplay from 'embla-carousel-autoplay';
import { cn } from '@/lib/utils';


interface HomePageProps {
  reviews: string[];
  products: Product[];
  slideshowImages: SlideshowImage[];
  collectionImages: CollectionImage[];
  featuredRecipes: FeaturedRecipe[];
  multicolumnItems: MulticolumnItem[];
}

export function HomePage({ reviews, products, slideshowImages, collectionImages, featuredRecipes, multicolumnItems }: HomePageProps) {
  const featuredProducts = products.slice(0, 4);
  const plugin = useRef(
    Autoplay({ delay: 3000, stopOnInteraction: false })
  );

  return (
    <div className="flex flex-col min-h-[100dvh]">
      <main className="flex-1">
        {/* Hero Slideshow */}
        <section className="relative w-full h-[50vh] md:h-[80vh] bg-background">
          <Carousel 
            className="w-full h-full" 
            opts={{ loop: true }} 
            plugins={[plugin.current]}
            onMouseEnter={() => plugin.current.stop()}
            onMouseLeave={() => plugin.current.reset()}
          >
            <CarouselContent>
              {slideshowImages.map((image, index) => (
                <CarouselItem key={index}>
                   <Link href={image.link || '#'}>
                      <div className="relative h-[50vh] md:h-[80vh]">
                        <Image
                          src={image.src}
                          alt={image.alt}
                          fill
                          data-ai-hint={image.hint}
                          className="object-cover"
                          priority={index === 0}
                        />
                      </div>
                   </Link>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="absolute left-4 top-1/2 -translate-y-1/2 hidden sm:flex" />
            <CarouselNext className="absolute right-4 top-1/2 -translate-y-1/2 hidden sm:flex" />
          </Carousel>
        </section>
        
        {/* New Image Section */}
        <section className="w-full relative py-12 md:py-24">
            <Image
                src="https://meals.dogspot.in/cdn/shop/files/Screenshot_2022-05-18_at_3.54.17_PM.png?v=1652869484&width=3840"
                alt="Happy dog eating a meal"
                fill
                data-ai-hint="happy dog"
                className="object-cover"
            />
            <div className="relative container mx-auto px-4 md:px-6 h-[400px] flex flex-col items-center justify-center text-center">
              <h2 className="text-3xl md:text-4xl font-bold text-black font-headline">Every Batch is Tried, Tested and Tasted by Our Team</h2>
              <p className="text-lg text-black mt-2">(Including our Pets)</p>
              <Link href="/products" passHref>
                  <Button size="lg" variant="outline" className="mt-6 bg-transparent border-black text-black hover:bg-black hover:text-white">
                      Order Now
                  </Button>
              </Link>
            </div>
        </section>

        {/* Collections Section */}
        <section className="py-12 md:py-24">
          <div className="container mx-auto px-4 md:px-6">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tighter text-center mb-10 font-headline">Collections</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
              {collectionImages.map((item) => (
                <Link key={item.category} href={`/products?category=${item.category}`} className="group block text-center">
                  <div className="overflow-hidden rounded-lg">
                    <Image
                      src={item.src}
                      alt={item.alt}
                      width={535}
                      height={535}
                      data-ai-hint={item.hint}
                      className="w-full h-auto object-cover aspect-square transition-transform duration-300 group-hover:scale-105"
                    />
                  </div>
                  <div className="mt-4 flex items-center justify-center font-semibold text-lg hover:text-primary">
                    {item.category}
                    <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
        
        {/* Featured Products Section */}
        <section className="py-12 md-py-24">
          <div className="container mx-auto px-4 md:px-6">
            <h2 className="text-2xl md:text-3xl font-bold tracking-tighter text-center mb-10 font-headline">Featured Products</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>

        {/* Featured Recipe Section */}
        <section className="py-12 md:py-24 bg-white">
          <div className="container mx-auto px-4 md:px-6">
            <h2 className="text-2xl md:text-3xl font-bold tracking-tighter text-center mb-10 font-headline">Featured Recipe</h2>
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8">
              {featuredRecipes.map((recipe) => (
                <div key={recipe.name} className="text-center">
                   <Image
                      src={recipe.image}
                      alt={recipe.name}
                      width={750}
                      height={750}
                      data-ai-hint={recipe.hint}
                      className="w-full rounded-lg object-cover aspect-square"
                    />
                  <h3 className="font-semibold text-lg mt-4">{recipe.name}</h3>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Money Back Guarantee Section */}
        <section className="py-16 md:py-32 bg-white">
          <div className="container mx-auto px-4 md:px-6">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold font-headline">100% Money Back Guarantee</h2>
                <p className="text-muted-foreground text-lg">
                  We give 100% money back guarantee. If your pet doesn't eat the food we will take the food back and refund the money.
                </p>
              </div>
              <div>
                <Image 
                  src="https://meals.dogspot.in/cdn/shop/files/Chime_StillsbyRohit_IndieDog_DogSpot_Meals.jpg?v=1654797236"
                  alt="Happy dog"
                  data-ai-hint="happy dog"
                  width={483}
                  height={730}
                  className="object-cover rounded-lg shadow-xl"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Multicolumn Section */}
        <section className="py-12 md:py-24">
          <div className="container mx-auto px-4 md:px-6">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tighter text-center mb-10 font-headline">Multicolumn</h2>
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8">
              {multicolumnItems.map((item) => (
                 <Link href={item.link || '#'} key={item.name}>
                    <Card className="overflow-hidden group">
                      <Image
                        src={item.image}
                        alt={item.name}
                        width={750}
                        height={750}
                        data-ai-hint={item.hint}
                        className="w-full object-cover aspect-square transition-transform duration-300 group-hover:scale-105"
                      />
                      <CardContent className="p-4 text-center">
                        <div className="font-semibold text-lg flex items-center justify-center">
                          {item.name}
                          {item.hasArrow && <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />}
                        </div>
                      </CardContent>
                    </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Customer Feedback */}
        <CustomerFeedback reviews={reviews} />
      </main>
    </div>
  );
}
