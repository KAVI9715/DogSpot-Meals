
import { NextResponse } from 'next/server';
import { sign } from 'jsonwebtoken';
import { serialize } from 'cookie';

const SECRET_KEY = process.env.JWT_SECRET || 'your-default-secret-key';
// Use the environment variable, but fall back to 'password' if it's not set.
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'password';

if (!process.env.ADMIN_PASSWORD) {
  console.warn("ADMIN_PASSWORD environment variable is not set. Using default password 'password'.");
}

export async function POST(request: Request) {
  const body = await request.json();
  const { password } = body;

  if (password === ADMIN_PASSWORD) {
    // Create a simple token
    const token = sign({ user: 'admin' }, SECRET_KEY, { expiresIn: '1h' });

    const cookie = serialize('auth_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV !== 'development',
      maxAge: 60 * 60, // 1 hour
      path: '/',
    });

    return new Response(JSON.stringify({ message: 'Login successful' }), {
        status: 200,
        headers: { 'Set-Cookie': cookie },
    });

  } else {
    return NextResponse.json({ message: 'Invalid credentials' }, { status: 401 });
  }
}
