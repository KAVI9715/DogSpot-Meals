
'use client';

import { useAuth } from '@/hooks/use-auth';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

export default function AccountPage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login');
    }
  }, [user, loading, router]);

  if (loading || !user) {
    return (
      <div className="flex justify-center items-center h-[calc(100vh-8rem)]">
        <Loader2 className="h-16 w-16 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-12 px-4 md:px-6">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold font-headline mb-8">My Account</h1>
        <Card>
          <CardHeader>
            <CardTitle>Welcome back, {user.email}!</CardTitle>
            <CardDescription>
              This is your account dashboard. More features coming soon!
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold">Your Information</h3>
              <p className="text-muted-foreground text-sm">Email: {user.email}</p>
            </div>
            <Button variant="outline" onClick={() => router.push('/admin/orders')}>
              View Order History
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
