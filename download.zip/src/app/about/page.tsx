import Link from "next/link";
import { Separator } from "@/components/ui/separator";

export default function AboutPage() {
  return (
    <div className="container mx-auto py-16 px-4 md:px-6">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold tracking-tight font-headline">About Us</h2>
      </div>
      <div className="max-w-4xl mx-auto">
        <h3 className="text-2xl md:text-3xl font-bold font-headline mb-6">Our Story</h3>
        <div className="space-y-6 text-muted-foreground text-lg">
            <p>
                Humans are selfish. First we created dogs, by selective breeding, to make an animal to be in a certain form, to perform a function for us; then we also created dog food.
            </p>
            <p>
                The most prevalent dog food available in the market was made to satisfy our selfish convenience. Kibble, which we call food, has no identity without a brand label on it. No one can tell what is in the kibble by tasting it or by seeing it. The world's largest kibble making companies started to focus on the Indian Market in the late 90s. Our Founder, Rana Atheya, was 18 then, with more than 15 years of experience of feeding homemade dog food to our dogs. His father, a Professor of veterinary sciences, taught him how to make balanced food for dogs. It was simple and straightforward with minimal ingredients. Dogs were happy and used to live long. Then came kibble which appeared to be the most convenient food with so many ingredients. Suddenly, dog food became complicated. Unfortunately the average age of the dogs has gradually reduced since the introduction of kibble.
            </p>
            <p>
                Our family and friends also suffered loss of our dear ones. We decided to make healthier dog food which would ensure healthier - longer lives of our pets. We started working on the dog food formulation in 2018. We identified the problem areas such as right balance, storage, palatability, transparency , digestibility and waste analysis for all types of dogs. We concluded that a homemade recipe is the panacea of all problems. Identifying and sourcing high quality, human grade fresh meat was our priority. DogSpot Meals is tested, tried and tasted by our human team before it reaches the market.
            </p>
        </div>
        <Separator className="my-12" />
        <div className="text-center space-y-4">
            <h3 className="text-xl md:text-2xl font-bold font-headline">What motivates us?</h3>
            <p className="text-muted-foreground text-lg">We help pets to live a Healthier, Happier & Longer life.</p>
        </div>
        <Separator className="my-12" />
        <div className="space-y-10">
          <h3 className="text-2xl md:text-3xl font-bold font-headline text-center">Our Alpha Pack</h3>
          <div className="space-y-4">
            <h3 className="text-xl md:text-2xl font-bold font-headline">Rana Atheya - Founder and CEO</h3>
            <p className="text-muted-foreground text-lg">
              Rana started up with DogSpot.in website in 2007 which became the most visited website for pet lovers in southeast Asia. He is known to be the most experienced professional in the Indian pet industry. He is one of the very few people who pursued their passion as a profession. He has been living with pets since his kindergarten.
            </p>
            <p className="text-muted-foreground text-lg">
              Rana founded DogSpot Meals to address the ever-growing needs of the dog-parent community for fresh, nutritious and healthy food. Since its inception, DogSpot Meals has grown very rapidly and it continues to move forward with its goal of increasing the happier and healthier lifespan of pets.
            </p>
            <Link href="https://in.linkedin.com/in/ratheya" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
              https://in.linkedin.com/in/ratheya
            </Link>
          </div>
          <div className="space-y-4">
            <h3 className="text-xl md:text-2xl font-bold font-headline">Gaurav Mittal - Co-Founder</h3>
            <p className="text-muted-foreground text-lg">
              Gaurav is a serial entrepreneur and a great mentor for setting up business which are fundamentally right. He was partner with one of the investors of DogSpot and liked our business so much that he decided to join this full time. He is new to pet industry and brings in out of the box, counter intuitive thinking.
            </p>
             <Link href="https://in.linkedin.com/in/gauravmittal1973" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
              https://in.linkedin.com/in/gauravmittal1973
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
