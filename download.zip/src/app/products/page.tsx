
import Link from 'next/link';
import { productCategories, categoryDescriptions, products as defaultProducts } from '@/lib/data';
import { type Product, getProducts } from '@/services/product-service';
import { ProductCard } from '@/components/product-card';
import { suggestSimilarCategories } from '@/ai/flows/suggest-similar-categories';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Lightbulb } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface ProductsPageProps {
  searchParams: {
    category?: Product['category'];
  };
}

async function getProductsData(category: Product['category'] | undefined) {
    let allProducts: Product[] = [];

    try {
        allProducts = await getProducts();
    } catch (e) {
        console.warn("Failed to fetch products from Firebase, falling back to local data.", e);
    }

    if (allProducts.length === 0) {
        allProducts = defaultProducts.map((p, i) => ({ ...p, id: i.toString() }));
    }

    const filteredProducts = category
        ? allProducts.filter((p) => p.category === category)
        : allProducts;

    let suggestions: string[] = [];
    if (filteredProducts.length === 0 && category) {
        // Gracefully fallback if the API key is not set or is a placeholder
        if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'YOUR_API_KEY') {
            try {
                const result = await suggestSimilarCategories({ category: category });
                suggestions = result.suggestions;
            } catch (error: unknown) {
                if (error instanceof Error) {
                    console.error(`Error suggesting categories: ${error.message}`);
                } else if (typeof error === 'string') {
                    console.error(`Error suggesting categories: ${error}`);
                } else {
                    console.error('An unknown error occurred while suggesting categories:', error);
                }
            }
        } else {
             console.warn("GEMINI_API_KEY not found or is a placeholder. Skipping category suggestions.");
        }
    }

    return { filteredProducts, suggestions };
}


export default async function ProductsPage({ searchParams }: ProductsPageProps) {
  const selectedCategory = searchParams.category;
  const { filteredProducts, suggestions } = await getProductsData(selectedCategory);

  const categoryDescription = selectedCategory ? categoryDescriptions[selectedCategory as keyof typeof categoryDescriptions] : null;

  return (
    <div className="container mx-auto py-12 px-4 md:px-6">
      <div className="flex flex-wrap justify-center gap-4 mb-12">
        {productCategories.map((category) => (
            <Button
                key={category}
                asChild
                variant="ghost"
                className={cn(
                    "rounded-full px-6 py-3 text-base font-semibold transition-all duration-300 ease-in-out shadow-sm hover:shadow-md",
                    selectedCategory === category
                        ? "bg-primary text-primary-foreground hover:bg-primary/90"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                )}
            >
                <Link href={`/products?category=${category}`}>{category}</Link>
            </Button>
        ))}
      </div>

      {categoryDescription && (
        <Card className="mb-12 bg-card">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">{selectedCategory}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-base text-muted-foreground whitespace-pre-line">{categoryDescription}</p>
          </CardContent>
        </Card>
      )}

      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <Alert className="max-w-xl mx-auto">
          <Lightbulb className="h-4 w-4" />
          <AlertTitle className="text-base">No products found for "{selectedCategory}"</AlertTitle>
          <AlertDescription>
            We don't have any meals in this category right now, but we're always expanding our menu!
            {selectedCategory && suggestions.length > 0 && (
                <div className="mt-4 flex flex-wrap gap-2 items-center">
                    <p className="text-muted-foreground">You might be interested in:</p>
                    {suggestions.map((suggestion) => (
                        <Button key={suggestion} variant="link" asChild className="p-1 h-auto">
                            <Link href={`/products?category=${suggestion}`}>{suggestion}</Link>
                        </Button>
                    ))}
                </div>
            )}
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
