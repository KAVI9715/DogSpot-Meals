
'use client';

import { useState } from 'react';
import Image from 'next/image';
import type { Product } from '@/services/product-service';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Minus, Plus, ShoppingCart, Share2, Link as LinkIcon, Mail, MessageCircle, Twitter, Facebook, Linkedin } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from '@/hooks/use-toast';
import { useCart } from '@/hooks/use-cart';
import { useRouter } from 'next/navigation';

interface ProductDetailsClientProps {
  product: Product;
}

export function ProductDetailsClient({ product }: ProductDetailsClientProps) {
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState('8');
  const { toast } = useToast();
  const { addItem } = useCart();
  const router = useRouter();

  const pageUrl = typeof window !== 'undefined' ? window.location.href : '';
  const shareText = `Check out this product from DogSpot Meals: ${product.name}`;

  const socialShares = [
      { name: 'WhatsApp', icon: MessageCircle, url: `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText + ' ' + pageUrl)}` },
      { name: 'Gmail', icon: Mail, url: `mailto:?subject=${encodeURIComponent(shareText)}&body=${encodeURIComponent(pageUrl)}` },
      { name: 'Facebook', icon: Facebook, url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(pageUrl)}` },
      { name: 'Twitter', icon: Twitter, url: `https://twitter.com/intent/tweet?url=${encodeURIComponent(pageUrl)}&text=${encodeURIComponent(shareText)}` },
      { name: 'LinkedIn', icon: Linkedin, url: `https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(pageUrl)}&title=${encodeURIComponent(shareText)}` },
  ];

  const handleCopy = () => {
      navigator.clipboard.writeText(pageUrl);
      toast({
          title: "Link Copied!",
          description: "The product link has been copied to your clipboard.",
      });
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  };

  const handleQuantityChange = (amount: number) => {
    setQuantity((prev) => Math.max(1, prev + amount));
  };
  
  const handleAddToCart = () => {
    addItem({ ...product, size: selectedSize, quantity });
    toast({
        title: "Added to cart!",
        description: `${quantity} x ${product.name} (Pack of ${selectedSize}) has been added to your cart.`,
    });
  }

  const handleBuyNow = () => {
    addItem({ ...product, size: selectedSize, quantity });
    router.push('/cart');
  }


  return (
    <div className="container mx-auto py-12 px-4 md:px-6">
      <div className="grid md:grid-cols-2 gap-12 items-start">
        <div className="grid gap-4">
            <div className="relative aspect-square">
                <Image
                    src={product.image1}
                    alt={product.name}
                    fill
                    data-ai-hint={product.image1Hint}
                    className="object-cover rounded-lg"
                />
            </div>
        </div>

        <div className="space-y-6">
          <div className="space-y-2">
            <h1 className="text-3xl md:text-4xl font-bold font-headline">{product.name}</h1>
            <p className="text-2xl font-bold text-primary">{formatPrice(product.price)}</p>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Size</h3>
            <RadioGroup value={selectedSize} onValueChange={setSelectedSize} className="flex gap-4">
              {['8', '16', '32'].map((size) => (
                <div key={size}>
                    <RadioGroupItem value={size} id={`size-${size}`} className="sr-only peer" />
                    <Label 
                        htmlFor={`size-${size}`}
                        className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer"
                    >
                        Pack of {size}
                    </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <h3 className="text-lg font-semibold">Quantity</h3>
            <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => handleQuantityChange(-1)}>
                    <Minus className="h-4 w-4" />
                </Button>
                <span className="text-xl font-semibold w-8 text-center">{quantity}</span>
                <Button variant="outline" size="icon" onClick={() => handleQuantityChange(1)}>
                    <Plus className="h-4 w-4" />
                </Button>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <Button size="lg" onClick={handleAddToCart}>
                <ShoppingCart className="mr-2 h-5 w-5" />
                Add to Cart
            </Button>
            <Button size="lg" variant="default" onClick={handleBuyNow}>Buy It Now</Button>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-2 font-headline">Product Description</h3>
            <div className="text-muted-foreground whitespace-pre-line space-y-4"
                 dangerouslySetInnerHTML={{ __html: product.description }} />
            
            {product.feedingGuideImage && (
              <div className="mt-6">
                <Image src={product.feedingGuideImage} alt="Feeding guidelines" width={480} height={480} className="rounded-lg" />
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-2">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <Share2 className="mr-2 h-4 w-4" />
                    Share
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>Share this Product</DialogTitle>
                    <DialogDescription>
                      Share this product with your friends and family.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 py-4">
                      {socialShares.map(({ name, icon: Icon, url }) => (
                          <a key={name} href={url} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-2 p-3 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors">
                              <Icon className="h-6 w-6" />
                              <span>{name}</span>
                          </a>
                      ))}
                  </div>
                  <div className="flex items-center space-x-2">
                      <div className="grid flex-1 gap-2">
                          <input
                              id="link"
                              defaultValue={pageUrl}
                              readOnly
                              className="h-9 flex-1 rounded-md border border-input bg-background px-3 text-sm"
                          />
                      </div>
                      <Button type="button" size="sm" className="px-3" onClick={handleCopy}>
                          <span className="sr-only">Copy</span>
                          <LinkIcon className="h-4 w-4" />
                      </Button>
                  </div>
                </DialogContent>
              </Dialog>
          </div>

        </div>
      </div>
    </div>
  );
}
