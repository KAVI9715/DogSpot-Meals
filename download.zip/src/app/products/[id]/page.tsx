
import { notFound } from 'next/navigation';
import { getProductById } from '@/services/product-service';
import { ProductDetailsClient } from './product-details-client';
import { products } from '@/lib/data';
import type { Product } from '@/services/product-service';

interface ProductPageProps {
  params: {
    id: string;
  };
}

export default async function ProductPage({ params }: ProductPageProps) {
  let product: Product | null = null;

  try {
    product = await getProductById(params.id);
  } catch (e) {
    console.error("Failed to fetch product from Firebase, falling back to local data.", e)
  }

  if (!product) {
    console.warn(`Product with ID ${params.id} not found in DB, falling back to local data.`);
    const localProduct = products.find((p, i) => i.toString() === params.id);
    if (localProduct) {
        product = { ...localProduct, id: params.id };
    }
  }
  
  if (!product) {
    // If it's still not found, then 404
    notFound();
  }

  return <ProductDetailsClient product={product} />;
}
