
'use client';

import { useState, Suspense, useEffect, useRef } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { PawPrint, Loader2 } from 'lucide-react';
import Link from 'next/link';
import { signInWithEmailAndPassword, RecaptchaVerifier, signInWithPhoneNumber, ConfirmationResult } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";


function LoginForm() {
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  
  const recaptchaVerifierRef = useRef<RecaptchaVerifier | null>(null);
  const recaptchaContainerRef = useRef<HTMLDivElement>(null);


  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    if (!auth) {
        toast({ title: 'Error', description: 'Firebase authentication is not configured. Please use the chat widget to connect your project.', variant: 'destructive'});
        setLoading(false);
        return;
    }

    try {
      await signInWithEmailAndPassword(auth, email, password);
      toast({
        title: 'Login Successful',
        description: "Welcome back!",
      });
      const redirectUrl = searchParams.get('redirect') || '/account';
      router.push(redirectUrl);
    } catch (error: any) {
      console.error(error);
       toast({
        title: 'Login Failed',
        description: error.message || 'An unexpected error occurred.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    if (!auth) {
        toast({ title: 'Error', description: 'Firebase authentication is not configured. Please use the chat widget to connect your project.', variant: 'destructive'});
        setLoading(false);
        return;
    }

    if (otpSent) {
        if (!confirmationResult) {
            toast({ title: 'Error', description: 'Something went wrong. Please try sending the OTP again.', variant: 'destructive'});
            setLoading(false);
            return;
        }
        try {
            await confirmationResult.confirm(otp);
            toast({ title: 'Login Successful', description: "Welcome back!" });
            const redirectUrl = searchParams.get('redirect') || '/account';
            router.push(redirectUrl);
        } catch (error: any) {
            toast({ title: 'Login Failed', description: error.message || 'Could not verify OTP.', variant: 'destructive'});
        } finally {
            setLoading(false);
        }
    } else {
        try {
            // Initialize reCAPTCHA verifier if it doesn't exist
            if (!recaptchaVerifierRef.current && recaptchaContainerRef.current) {
                recaptchaVerifierRef.current = new RecaptchaVerifier(auth, recaptchaContainerRef.current, {
                    'size': 'invisible',
                    'callback': () => {
                        // reCAPTCHA solved, ready to send OTP.
                    }
                });
            }
            
            const phoneNumber = phone.startsWith('+') ? phone : `+91${phone}`;
            const verifier = recaptchaVerifierRef.current!;
            const result = await signInWithPhoneNumber(auth, phoneNumber, verifier);
            setConfirmationResult(result);
            setOtpSent(true);
            toast({ title: 'OTP Sent', description: `An OTP has been sent to ${phoneNumber}.` });
        } catch (error: any) {
            console.error("OTP Send Error:", error);
            setOtpSent(false);

            if (error.code === 'auth/operation-not-allowed') {
                toast({
                    title: 'Phone Sign-In Not Enabled',
                    description: "Please enable the Phone Number sign-in provider in your Firebase console's Authentication settings.",
                    variant: 'destructive',
                    duration: 10000,
                });
            } else {
                 toast({ title: 'Failed to Send OTP', description: error.message || 'Please check the phone number and try again.', variant: 'destructive'});
            }
            // Reset reCAPTCHA
            // @ts-ignore
            if (window.grecaptcha && recaptchaVerifierRef.current?.widgetId !== undefined) {
                // @ts-ignore
                window.grecaptcha.reset(recaptchaVerifierRef.current.widgetId);
            }
        } finally {
            setLoading(false);
        }
    }
  }

  return (
    <Card className="w-full max-w-sm">
        <CardHeader className="text-center">
        <div className="flex justify-center mb-4">
            <PawPrint className="h-10 w-10 text-primary" />
        </div>
        <CardTitle className="text-2xl font-headline">Customer Login</CardTitle>
        <CardDescription>Sign in to your DogSpot Delights account.</CardDescription>
        </CardHeader>
        <CardContent>
            {/* This container is essential for the invisible reCAPTCHA to work */}
            <div ref={recaptchaContainerRef}></div>
            <Tabs defaultValue="email" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="email" disabled={otpSent}>Email</TabsTrigger>
                    <TabsTrigger value="phone">Phone</TabsTrigger>
                </TabsList>
                <TabsContent value="email">
                    <form onSubmit={handleEmailSubmit} className="space-y-4 pt-4">
                        <div className="space-y-2">
                            <Label htmlFor="email-login">Email</Label>
                            <Input
                                id="email-login"
                                type="email"
                                placeholder="you@example.com"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                        </div>
                        <div className="space-y-2">
                        <Label htmlFor="password-email">Password</Label>
                        <Input
                            id="password-email"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                        </div>
                        <Button type="submit" className="w-full" disabled={loading}>
                        {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Sign In
                        </Button>
                    </form>
                </TabsContent>
                <TabsContent value="phone">
                     <form onSubmit={handlePhoneSubmit} className="space-y-4 pt-4">
                        {otpSent ? (
                            <>
                                <div className="text-center">
                                    <h3 className="font-bold">Verify OTP</h3>
                                    <p className="text-sm text-muted-foreground">Enter the 6-digit code sent to your mobile number.</p>
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="otp">Enter OTP</Label>
                                    <Input
                                        id="otp"
                                        type="text"
                                        placeholder="6-digit code"
                                        value={otp}
                                        onChange={(e) => setOtp(e.target.value)}
                                        required
                                    />
                                </div>
                                <Button type="submit" className="w-full" disabled={loading}>
                                    {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                    Verify OTP
                                </Button>
                                <Button variant="link" size="sm" className="w-full" onClick={() => { setOtpSent(false); setConfirmationResult(null); }}>Back to phone number entry</Button>
                            </>
                        ) : (
                            <>
                                <div className="space-y-2">
                                    <Label htmlFor="phone">Phone Number</Label>
                                    <Input
                                        id="phone"
                                        type="tel"
                                        placeholder="Your 10-digit phone number"
                                        value={phone}
                                        onChange={(e) => setPhone(e.target.value)}
                                        required
                                    />
                                </div>
                                <Button type="submit" className="w-full" disabled={loading}>
                                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    Send OTP
                                </Button>
                            </>
                        )}
                    </form>
                </TabsContent>
            </Tabs>
        <div className="mt-4 text-center text-sm">
            Don't have an account?{' '}
            <Link href="/register" className="underline">
            Sign up
            </Link>
        </div>
        </CardContent>
    </Card>
  );
}


export default function CustomerLoginPage() {
    return (
        <div className="flex items-center justify-center min-h-[calc(100vh-8rem)] bg-background">
            <Suspense fallback={<Loader2 className="h-16 w-16 animate-spin text-primary" />}>
                <LoginForm />
            </Suspense>
        </div>
    )
}
