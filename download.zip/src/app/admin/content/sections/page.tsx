
'use client';

import { useState, useEffect } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Trash2 } from 'lucide-react';
import Image from 'next/image';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { getSiteContent, updateSiteContent, type SiteContent } from '@/services/site-content-service';
import { Switch } from '@/components/ui/switch';

const formSchema = z.object({
  featuredRecipes: z.array(z.object({
    name: z.string().min(1, "Name is required."),
    image: z.string().url("Please enter a valid image URL."),
    hint: z.string().min(1, "AI hint is required."),
  })),
  multicolumnItems: z.array(z.object({
      name: z.string().min(1, "Name is required."),
      image: z.string().url("Please enter a valid image URL."),
      hint: z.string().min(1, "AI hint is required."),
      hasArrow: z.boolean().optional(),
      link: z.string().url("Please enter a valid URL.").or(z.literal('')).optional(),
  })),
});

type SectionsFormValues = z.infer<typeof formSchema>;

export default function SectionsSettingsPage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const form = useForm<SectionsFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      featuredRecipes: [],
      multicolumnItems: [],
    },
  });

  const { fields: recipeFields, append: appendRecipe, remove: removeRecipe } = useFieldArray({
    control: form.control,
    name: "featuredRecipes",
  });

  const { fields: multicolumnFields, append: appendMulticolumn, remove: removeMulticolumn } = useFieldArray({
    control: form.control,
    name: "multicolumnItems",
  });

  useEffect(() => {
    async function fetchContent() {
      setLoading(true);
      try {
        const content = await getSiteContent();
        form.reset({ 
            featuredRecipes: content.featuredRecipes,
            multicolumnItems: content.multicolumnItems
        });
      } catch (error) {
        toast({ title: "Error", description: "Failed to load homepage sections content.", variant: 'destructive' });
      } finally {
        setLoading(false);
      }
    }
    fetchContent();
  }, [form, toast]);

  const onSubmit = async (data: SectionsFormValues) => {
    setSaving(true);
    try {
      const contentToUpdate: Partial<SiteContent> = { 
          featuredRecipes: data.featuredRecipes,
          multicolumnItems: data.multicolumnItems
      };
      await updateSiteContent(contentToUpdate);
      toast({ title: 'Success!', description: 'Homepage sections have been updated.' });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to save homepage sections.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center h-full"><Loader2 className="h-16 w-16 animate-spin text-primary" /></div>;
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold font-headline">Homepage Sections</h1>
          <Button type="submit" disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Save All Changes
          </Button>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Featured Recipe Section</CardTitle>
            <CardDescription>Items in the "Featured Recipe" section.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {recipeFields.map((field, index) => (
              <Card key={field.id} className="p-4">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                     <div className="space-y-4">
                         <FormField control={form.control} name={`featuredRecipes.${index}.image`} render={({ field }) => ( <FormItem> <FormLabel>Image URL</FormLabel> <FormControl><Input {...field} /></FormControl> <FormMessage /> </FormItem> )}/>
                         {form.getValues(`featuredRecipes.${index}.image`) && <Image src={form.getValues(`featuredRecipes.${index}.image`)} alt={form.getValues(`featuredRecipes.${index}.name`)} width={200} height={200} className="rounded-md object-cover aspect-square" />}
                     </div>
                     <div className="space-y-4">
                         <FormField control={form.control} name={`featuredRecipes.${index}.name`} render={({ field }) => ( <FormItem> <FormLabel>Name</FormLabel> <FormControl><Input {...field} /></FormControl> <FormMessage /> </FormItem> )}/>
                         <FormField control={form.control} name={`featuredRecipes.${index}.hint`} render={({ field }) => ( <FormItem> <FormLabel>AI Hint</FormLabel> <FormControl><Input {...field} placeholder="e.g. 'chicken rice'" /></FormControl> <FormMessage /> </FormItem> )}/>
                         <Button type="button" variant="destructive" size="sm" onClick={() => removeRecipe(index)}> <Trash2 className="mr-2 h-4 w-4" /> Remove Recipe </Button>
                     </div>
                 </div>
              </Card>
            ))}
          </CardContent>
          <CardFooter>
            <Button type="button" variant="outline" onClick={() => appendRecipe({ name: '', image: '', hint: '' })}> Add Recipe </Button>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Multicolumn Section</CardTitle>
            <CardDescription>Items in the "Multicolumn" section.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
             {multicolumnFields.map((field, index) => (
              <Card key={field.id} className="p-4">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                    <div className="space-y-4">
                        <FormField control={form.control} name={`multicolumnItems.${index}.image`} render={({ field }) => ( <FormItem> <FormLabel>Image URL</FormLabel> <FormControl><Input {...field} /></FormControl> <FormMessage /> </FormItem> )}/>
                        {form.getValues(`multicolumnItems.${index}.image`) && <Image src={form.getValues(`multicolumnItems.${index}.image`)} alt={form.getValues(`multicolumnItems.${index}.name`)} width={200} height={200} className="rounded-md object-cover aspect-square" />}
                    </div>
                    <div className="space-y-4">
                        <FormField control={form.control} name={`multicolumnItems.${index}.name`} render={({ field }) => ( <FormItem> <FormLabel>Name</FormLabel> <FormControl><Input {...field} /></FormControl> <FormMessage /> </FormItem> )}/>
                        <FormField control={form.control} name={`multicolumnItems.${index}.link`} render={({ field }) => ( <FormItem> <FormLabel>Link URL</FormLabel> <FormControl><Input {...field} placeholder="/products" /></FormControl> <FormMessage /> </FormItem> )}/>
                        <FormField control={form.control} name={`multicolumnItems.${index}.hint`} render={({ field }) => ( <FormItem> <FormLabel>AI Hint</FormLabel> <FormControl><Input {...field} placeholder="e.g. 'chicken rice pack'" /></FormControl> <FormMessage /> </FormItem> )}/>
                        <FormField control={form.control} name={`multicolumnItems.${index}.hasArrow`} render={({ field }) => ( <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm"> <div className="space-y-0.5"> <FormLabel>Show Arrow</FormLabel> </div> <FormControl> <Switch checked={field.value} onCheckedChange={field.onChange} /> </FormControl> </FormItem> )}/>
                        <Button type="button" variant="destructive" size="sm" onClick={() => removeMulticolumn(index)}> <Trash2 className="mr-2 h-4 w-4" /> Remove Item </Button>
                    </div>
                 </div>
              </Card>
            ))}
          </CardContent>
           <CardFooter>
            <Button type="button" variant="outline" onClick={() => appendMulticolumn({ name: '', image: '', hint: '', link: '', hasArrow: false })}> Add Item </Button>
          </CardFooter>
        </Card>
      </form>
    </Form>
  );
}
