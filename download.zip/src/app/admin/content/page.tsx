
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, GalleryHorizontal, LayoutTemplate, Rows, SlidersHorizontal } from 'lucide-react';

const contentSections = [
    {
        title: 'Homepage Slideshow',
        description: 'Manage the large rotating images at the top of your homepage.',
        href: '/admin/content/slideshow',
        icon: GalleryHorizontal,
    },
    {
        title: 'Homepage Collections',
        description: 'Edit the product collection links displayed on the homepage.',
        href: '/admin/content/collections',
        icon: LayoutTemplate,
    },
    {
        title: 'Homepage Sections',
        description: 'Update the "Featured Recipe" and "Multicolumn" sections.',
        href: '/admin/content/sections',
        icon: Rows,
    }
]

export default function AdminContentPage() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold font-headline">Site Content</h1>
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {contentSections.map((section) => (
            <Card key={section.href}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-medium">{section.title}</CardTitle>
                <section.icon className="w-5 h-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <p className="text-sm text-muted-foreground mb-4">{section.description}</p>
                 <Button asChild variant="outline" size="sm">
                    <Link href={section.href}>
                        Edit
                        <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                </Button>
            </CardContent>
            </Card>
        ))}
      </div>
    </div>
  );
}
