
'use client';

import { useState, useEffect } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Trash2 } from 'lucide-react';
import Image from 'next/image';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { getSiteContent, updateSiteContent, type SiteContent } from '@/services/site-content-service';

const formSchema = z.object({
  slideshowImages: z.array(z.object({
    src: z.string().url("Please enter a valid image URL."),
    alt: z.string().min(1, "Alt text is required."),
    hint: z.string().min(1, "AI hint is required."),
    link: z.string().url("Please enter a valid URL for the link.").or(z.literal('')),
  })),
});

type SlideshowFormValues = z.infer<typeof formSchema>;

export default function SlideshowSettingsPage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const form = useForm<SlideshowFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      slideshowImages: [],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "slideshowImages",
  });

  useEffect(() => {
    async function fetchContent() {
      setLoading(true);
      try {
        const content = await getSiteContent();
        if (content.slideshowImages) {
          form.reset({ slideshowImages: content.slideshowImages });
        }
      } catch (error) {
        toast({ title: "Error", description: "Failed to load slideshow content.", variant: 'destructive' });
      } finally {
        setLoading(false);
      }
    }
    fetchContent();
  }, [form, toast]);

  const onSubmit = async (data: SlideshowFormValues) => {
    setSaving(true);
    try {
      const contentToUpdate: Partial<SiteContent> = { slideshowImages: data.slideshowImages };
      await updateSiteContent(contentToUpdate);
      toast({ title: 'Success!', description: 'Slideshow has been updated.' });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to save slideshow.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center h-full"><Loader2 className="h-16 w-16 animate-spin text-primary" /></div>;
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold font-headline">Homepage Slideshow</h1>
          <Button type="submit" disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Save Changes
          </Button>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Manage Slides</CardTitle>
            <CardDescription>Update the images, text, and links for your homepage slideshow.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {fields.map((field, index) => (
              <Card key={field.id} className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                    <div className="space-y-4">
                         <FormField
                            control={form.control}
                            name={`slideshowImages.${index}.src`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Image URL</FormLabel>
                                <FormControl><Input {...field} /></FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                            />
                        {form.getValues(`slideshowImages.${index}.src`) && (
                            <Image src={form.getValues(`slideshowImages.${index}.src`)} alt={`Slide ${index + 1}`} width={200} height={100} className="rounded-md object-cover" />
                        )}
                    </div>
                    <div className="space-y-4">
                        <FormField
                            control={form.control}
                            name={`slideshowImages.${index}.alt`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Alt Text</FormLabel>
                                <FormControl><Input {...field} placeholder="Descriptive text for accessibility" /></FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                            />
                        <FormField
                            control={form.control}
                            name={`slideshowImages.${index}.hint`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>AI Hint</FormLabel>
                                <FormControl><Input {...field} placeholder="e.g., 'happy dog'" /></FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                            />
                         <FormField
                            control={form.control}
                            name={`slideshowImages.${index}.link`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Link URL</FormLabel>
                                <FormControl><Input {...field} placeholder="/products" /></FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                            />
                        <Button type="button" variant="destructive" size="sm" onClick={() => remove(index)}>
                            <Trash2 className="mr-2 h-4 w-4" /> Remove Slide
                        </Button>
                    </div>
                </div>
              </Card>
            ))}
          </CardContent>
          <CardFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => append({ src: '', alt: '', hint: '', link: '' })}
            >
              Add Slide
            </Button>
          </CardFooter>
        </Card>
      </form>
    </Form>
  );
}
