
'use client';

import { useEffect, useState } from 'react';
import { notFound, useRouter, useParams } from 'next/navigation';
import { getProductById } from '@/services/product-service';
import type { Product } from '@/services/product-service';
import { ProductForm } from '@/components/admin/product-form';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function EditProductPage() {
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const params = useParams();
  const id = params.id as string;

  useEffect(() => {
    if (!id) return;
    
    async function fetchProduct() {
      try {
        const fetchedProduct = await getProductById(id);
        if (!fetchedProduct) {
            toast({
                title: 'Product not found',
                description: `A product with ID ${id} could not be found.`,
                variant: 'destructive'
            })
            return notFound();
        }
        setProduct(fetchedProduct);
      } catch (error) {
        console.error("Error fetching product:", error);
        toast({
            title: 'Error',
            description: 'There was an error fetching the product details.',
            variant: 'destructive'
        })
      } finally {
        setLoading(false);
      }
    }

    fetchProduct();
  }, [id, toast]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[calc(100vh-8rem)]">
        <Loader2 className="h-16 w-16 animate-spin text-primary" />
      </div>
    );
  }

  if (!product) {
    // This case will be handled by notFound, but as a fallback
    return <p>Product not found.</p>;
  }

  return (
    <div>
      <h1 className="text-2xl font-bold font-headline mb-6">Edit Product</h1>
      <ProductForm product={product} />
    </div>
  );
}
