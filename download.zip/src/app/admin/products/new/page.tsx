
import { ProductForm } from '@/components/admin/product-form';

export default function NewProductPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold font-headline mb-6">Add a New Product</h1>
      <ProductForm />
    </div>
  );
}
