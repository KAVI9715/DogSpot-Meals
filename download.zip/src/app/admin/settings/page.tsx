
'use client';

import { useState, useEffect } from 'react';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '@/lib/firebase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import { seedDatabase } from '@/services/seed-db';

interface Settings {
  siteTitle: string;
  currency: 'INR' | 'USD' | 'EUR';
  taxRate: number;
  bannerImage: string;
  contactEmail: string;
}

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<Settings>({
    siteTitle: '',
    currency: 'INR',
    taxRate: 0,
    bannerImage: '',
    contactEmail: '',
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [newBannerImage, setNewBannerImage] = useState<File | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    async function fetchSettings() {
      if (!db) {
          toast({
            title: "Firebase Not Connected",
            description: "Please connect your Firebase project in the chat widget to manage settings.",
            variant: "destructive",
          });
          setLoading(false);
          return;
      }
      try {
        const settingsDocRef = doc(db, 'settings', 'general');
        const docSnap = await getDoc(settingsDocRef);
        if (docSnap.exists()) {
          setSettings(docSnap.data() as Settings);
        } else {
          console.log('No such document! Using default settings.');
        }
      } catch (error) {
        console.error('Error fetching settings:', error);
        toast({
          title: 'Error',
          description: 'Could not load store settings.',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    }
    fetchSettings();
  }, [toast]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      setNewBannerImage(event.target.files[0]);
    }
  };

  const handleSave = async () => {
    if (!db || !storage) {
        toast({ title: 'Error', description: 'Firebase not connected.', variant: 'destructive' });
        return;
    }
    setSaving(true);
    try {
      let bannerImageUrl = settings.bannerImage;

      if (newBannerImage) {
        const storageRef = ref(storage, `settings/banner/${newBannerImage.name}`);
        const uploadTask = await uploadBytes(storageRef, newBannerImage);
        bannerImageUrl = await getDownloadURL(uploadTask.ref);
      }
      
      const updatedSettings = { ...settings, bannerImage: bannerImageUrl };

      const settingsDocRef = doc(db, 'settings', 'general');
      await setDoc(settingsDocRef, updatedSettings, { merge: true });
      
      setSettings(updatedSettings);

      toast({
        title: 'Success!',
        description: 'Your settings have been saved.',
      });
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: 'Error',
        description: 'Failed to save settings. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };
  
  const handleSeedDatabase = async () => {
    setSeeding(true);
    try {
      const result = await seedDatabase();
      if (result.success) {
        toast({
            title: "Database Seeded!",
            description: result.message,
        });
      } else {
        toast({
            title: "Database Seeding Failed",
            description: result.message,
            variant: "destructive",
        });
      }
    } catch (error: unknown) {
        const message = error instanceof Error ? error.message : "An unknown error occurred.";
        console.error("Error seeding database from page:", error);
        toast({
            title: "Database Seeding Failed",
            description: message,
            variant: "destructive",
        });
    } finally {
        setSeeding(false);
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[calc(100vh-8rem)]">
        <Loader2 className="h-16 w-16 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <>
      <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold font-headline">Store Settings</h1>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Save
          </Button>
      </div>
      <div className="space-y-8 mt-6">
        <Card>
          <CardHeader>
            <CardTitle>General Settings</CardTitle>
            <CardDescription>Update your store's general information.</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <Label htmlFor="siteTitle">Site Title</Label>
                <Input
                  id="siteTitle"
                  value={settings.siteTitle}
                  onChange={(e) => setSettings({ ...settings, siteTitle: e.target.value })}
                  placeholder="Your Store Name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contactEmail">Contact Email</Label>
                <Input
                  id="contactEmail"
                  type="email"
                  value={settings.contactEmail}
                  onChange={(e) => setSettings({ ...settings, contactEmail: e.target.value })}
                  placeholder="contact@yourstore.com"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="currency">Currency</Label>
                <Select
                  value={settings.currency}
                  onValueChange={(value: 'INR' | 'USD' | 'EUR') => setSettings({ ...settings, currency: value })}
                >
                  <SelectTrigger id="currency">
                    <SelectValue placeholder="Select a currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="INR">INR (₹)</SelectItem>
                    <SelectItem value="USD">USD ($)</SelectItem>
                    <SelectItem value="EUR">EUR (€)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="taxRate">Tax Rate (%)</Label>
                <Input
                  id="taxRate"
                  type="number"
                  value={settings.taxRate}
                  onChange={(e) => setSettings({ ...settings, taxRate: parseFloat(e.target.value) || 0 })}
                  placeholder="e.g., 5"
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="bannerImage">Store Banner Image</Label>
                 <Input
                  id="bannerImage"
                  type="file"
                  onChange={handleFileChange}
                  className="file:text-primary file:font-medium"
                />
                {settings.bannerImage && (
                  <div className="mt-4">
                    <p className="text-sm text-muted-foreground mb-2">Current Banner:</p>
                    <img src={settings.bannerImage} alt="Current Banner" className="rounded-md max-h-40 object-contain border" />
                  </div>
                )}
              </div>
            </form>
          </CardContent>
        </Card>

        <Card>
            <CardHeader>
                <CardTitle>Database Tools</CardTitle>
                <CardDescription>Use these tools to manage your product database.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between rounded-lg border p-4">
                    <div>
                        <h3 className="font-semibold">Seed Database</h3>
                        <p className="text-sm text-muted-foreground">
                            Populate your database with the initial product and site content.
                        </p>
                    </div>
                    <Button onClick={handleSeedDatabase} disabled={seeding} variant="secondary" className="mt-2 md:mt-0">
                        {seeding ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                        Seed Database
                    </Button>
                </div>
            </CardContent>
        </Card>
      </div>
    </>
  );
}
