
import { HomePage } from '@/components/home-page';
import { customerReviews, products as defaultProducts } from '@/lib/data';
import { highlightEmotionalReviews } from '@/ai/flows/highlight-emotional-reviews';
import { getProducts, type Product } from '@/services/product-service';
import { getSiteContent, SiteContent } from '@/services/site-content-service';

async function getReviews() {
    if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY === 'YOUR_API_KEY') {
        console.warn('GEMINI_API_KEY not set. Using default reviews.');
        return customerReviews.slice(0, 4);
    }
    try {
        const { highlightedReviews } = await highlightEmotionalReviews({ reviews: customerReviews });
        return highlightedReviews.length > 0 ? highlightedReviews : customerReviews.slice(0, 4);
    } catch (error) {
        console.warn('Could not fetch AI-powered reviews. Falling back to default reviews.', error);
        return customerReviews.slice(0, 4);
    }
}

async function getHomePageProducts(): Promise<Product[]> {
    try {
        const productsFromDb = await getProducts();
        if (productsFromDb.length > 0) {
            return productsFromDb;
        }
        console.warn('No products in DB. Using default product data.');
        return defaultProducts.map((p, i) => ({ ...p, id: i.toString() }));
    } catch (error) {
        console.warn('Could not fetch products from DB. Falling back to default products.', error);
        return defaultProducts.map((p, i) => ({ ...p, id: i.toString() }));
    }
}

async function getHomePageContent(): Promise<SiteContent> {
    try {
        const content = await getSiteContent();
        return content;
    } catch (error) {
        console.error("Could not fetch site content from DB. This is a critical error.", error);
        // Fallback to empty arrays to prevent render errors, but this indicates a problem.
        return {
            slideshowImages: [],
            collectionImages: [],
            featuredRecipes: [],
            multicolumnItems: [],
        };
    }
}

export default async function Home() {
    const reviews = await getReviews();
    const products = await getHomePageProducts();
    const { slideshowImages, collectionImages, featuredRecipes, multicolumnItems } = await getHomePageContent();
    
    return <HomePage 
        reviews={reviews} 
        products={products}
        slideshowImages={slideshowImages}
        collectionImages={collectionImages}
        featuredRecipes={featuredRecipes}
        multicolumnItems={multicolumnItems}
    />;
}
