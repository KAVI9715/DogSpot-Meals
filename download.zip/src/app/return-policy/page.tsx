
export default function ReturnPolicyPage() {
  return (
    <div className="container mx-auto py-16 px-4 md:px-6">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold tracking-tight font-headline">Return &amp; Refund Policy</h2>
      </div>
      <div className="max-w-4xl mx-auto space-y-6 text-muted-foreground text-lg">
        <p>
          <strong>Definition:</strong> 'Return' is defined as the action of giving back the item purchased by the customer to the Seller/DogSpot Meals on the DogSpot Meals website. Following situations may arise:
        </p>
        <ul className="list-decimal list-inside space-y-2">
          <li>Item was damaged in transit</li>
          <li>Wrong item was received</li>
          <li>If your pet doesn't eat the food we will take the food back and refund the money. No questions asked period.</li>
        </ul>
        <p>
          Return could also result in refund of money in some of the cases.
        </p>
        <p>
          We encourage the customer to review the Product details before making the purchase decision.
        </p>
        <h3 className="text-xl md:text-2xl font-bold font-headline mt-8">The following RULES apply to this Policy:</h3>
        <ol className="list-decimal list-inside space-y-2">
          <li>
            In case of a damaged or wrong item customer needs to raise the request within 24hours from the time of delivery. Once the customer has raised the request, he/she needs to provide visual proof (an image) of the damaged product to DogSpot Meals within 3 days from the time of delivery.
          </li>
          <li>
            In the event the Seller accepts the return request raised by the customer, DogSpot Meals will arrange the pickup and then the refund shall be credited to the customer’s account.
          </li>
          <li>
            Refund will only be processed after a quality check of the product by experts of DogSpot Meals.
          </li>
        </ol>
      </div>
    </div>
  );
}
