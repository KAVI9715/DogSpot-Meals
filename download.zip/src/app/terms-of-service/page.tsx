
export default function TermsOfServicePage() {
  return (
    <div className="container mx-auto py-16 px-4 md:px-6">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold tracking-tight font-headline">Terms of service</h2>
      </div>
      <div className="max-w-4xl mx-auto space-y-6 text-muted-foreground text-lg">
        <p>
          Welcome to Meals.DogSpot.in. The following are the rules ("Terms") that govern use of the Meals.DogSpot.in Web site ("Site"). By using, adding information, or visiting the Site, you expressly agree that you have read, understood and are bound by the terms and conditions set out herein and all applicable laws and regulations governing the Site, including but not to any additional or amended terms or condition as applicable from time to time, regardless of how you subscribed to or use the services.
        </p>
        <p>
          Meals.DogSpot.in or PetsGlam Services Pvt Ltd ("DogSpot Meals"), whose registered office is Shop No-4, Super Mart-II, DLF City, Phase-IV, Gurgaon, Gurgaon, Haryana, 122009 India. Our company registration number is U74999DL2011PTC217046, Delhi, reserves the right to change these Terms at any time, effective immediately upon posting on the site.
        </p>
        <p>
          <strong>Authorized Site Visits:</strong> You agree that you are only authorized to visit, view, and retain a copy of pages of this Site for your own personal use, and that you shall not duplicate, download, publish, modify, scrape, or otherwise distribute the material on this Site for any commercial use, or for any purpose other than as described in these Terms.
        </p>
        <p>
          <strong>Registering with Meals.DogSpot.in:</strong> In order to take advantage of certain features on the Site, you may be required to register with Meals.DogSpot. For example, you may be required to register with DogSpot Meals if you want to set up a "My Profile" on DogSpot Meals, where you can view a record of your contributions in the form of ratings, feedback, get email alerts, etc.. DogSpot Meals use any personal information that you provide to Meals.DogSpot.in during any registration process is governed by DogSpot Meals privacy policy.
        </p>
        <p>
          <strong>Authentication Service:</strong> DogSpot Meals may permit You to register for the Website through certain third party services, such as Facebook Connect and Google (“Authentication Service”). By registering for the Website using an Authentication Service, you agree that DogSpot Meals may access your account information from the Authentication Service and you agree to any and all terms of use of the Authentication Service regarding your use of the Website via the Authentication Service. You agree that any Authentication Service is a Reference Site and you are solely responsible for your interactions with the Authentication Service as a result of accessing the Website through the Authentication Service.
        </p>
        <p>
          <strong>Meals.DogSpot.in</strong> only collect your Personal Information to conduct its business and to enable itself to deliver and improve its Services.
        </p>
        <p>
          DogSpot Meals will only disclose your Personal Information in accordance with this Privacy Policy.
        </p>
        <p>
          If you decline to submit personal information to us, then we will unfortunately not be in a position to provide the Services to you.
        </p>
        <p>
          Any of your information that you provide when you use Meals.DogSpot.in an unencrypted manner and/or to an open, public environment or forum including (without limitation) any blog, chat room, albums, community, classifieds or discussion board, is not confidential, does not constitute Personal Information, and is not subject to protection under Privacy Policy.
        </p>
        <p>
          Since such public environments are accessible by third parties, it is possible that third parties may collect and collate and use such information for their own purposes. You should accordingly be careful when deciding to share any of your Personal Information in such public environments. DogSpot Meals is not liable to you or any third party for any damages that you or any third party may suffer howsoever arising from your disclosure of Personal Information in any public environment. You accordingly disclose information in a public environment at your own risk.
        </p>
        <p>
          <strong>DogSpot Meals Account:</strong> If you register for a DogSpot Meals account, you will be allowed to save and personalize DogSpot Meals content, receive, add, and view comments/ratings from existing and future features provided by the DogSpot Meals system, and post ratings and articles about DogSpot Meals businesses and other user articles. By having an account with DogSpot Meals, you agree to take full responsibility for maintaining the confidentiality of your account user name, password, and all related activity that occurs under your account user name. If you violate these Terms, DogSpot Meals may, at its sole discretion, terminate your accounts, remove or modify any account-related content or access (including, but not limited to, articles, and user profile information), or take any other action that DogSpot Meals believes is appropriate.
        </p>
        <p>
          <strong>Access and Interference:</strong> You agree that you will not use any robot, spider, other automatic devices, or manual process to monitor or copy our pages or the content contained thereon or for any other unauthorized purpose without our prior expressed written permission. You agree that you will not use any device, software, or routine to interfere or attempt to interfere with the proper working of the Site. You agree that you will not copy, reproduce, alter, modify, create derivative works from, or publicly display any content (except for your own personal, non-commercial use) from our Web site without the prior expressed written permission of DogSpot Meals.
        </p>
        <p>
          <strong>Unauthorized Use of the Site:</strong> Illegal and/or unauthorized uses of the Site, including, but not limited to, unauthorized framing of or linking to the Site or unauthorized use of any robot, spider, or other automated devices on the Site, will be investigated and subject to appropriate legal action, including, without limitation, civil, criminal, and injunctive redress.
        </p>
        <p>
          <strong>Violation of the Terms:</strong> You agree that monetary damages may not provide a sufficient remedy to DogSpot Meals for violations of these terms of use and you consent to injunctive or other equitable relief for such violations.
        </p>
        <p>
          <strong>Disclaimers:</strong> Dogspot Meals does not promise that the site will be inoffensive, error-free or uninterrupted, or that it will provide specific information from use of the site or any content, search, or link on it. The site and its content are delivered on an "as-is" and "as available" basis. Dogspot Meals cannot ensure that files you download from the site will be free of viruses or contamination or destructive features. Dogspot Meals disclaims all warranties, express or implied, including any implied warranties of merchantability and fitness for a particular purpose. Dogspot Meals will not be liable for any damages of any kind arising from the use of this site, including, without limitation, direct, indirect, incidental, and punitive and consequential damages. DogSpot Meals disclaims any and all liability for the acts, omissions, and conduct of any third-party users, DogSpot Meals users, advertisers, and/or sponsors on the Site, in connection with the Site, or otherwise related to your use of the Site. DogSpot Meals is not responsible for the products, services, actions, or failure to act of any third party in connection with or referenced on the Site. Without limiting the foregoing, you may report the misconduct of users and/or third-party advertisers or service and/or product providers referenced on or included in the Site to DogSpot Meals at meals@DogSpot.in. DogSpot Meals may investigate the claim and take appropriate action, at its sole discretion.
        </p>
        <p>
          <strong>Limitation of Laibility:</strong> In no event shall DogSpot Meals and/or its employee, affiliates be liable for any direct, indirect, punitive, incidental, special, consequential damages or any damages whatsoever including, without limitation, damages for loss of use, data or profits, arising out of or in any way connected with the use or performance of Meals.DogSpot.in sites/services, with the delay or inability to use Meals.DogSpot.in sites/services or related services, the provision of or failure to provide services, or for any information, software, products, services and related graphics obtained through Meals.DogSpot.in sites/services, or otherwise arising out of the use of Meals.DogSpot.in sites/services, whether based on contract, tort, negligence, strict liability or otherwise, even if Meals.DogSpot.in or any of employees, affiliates had been advised of the possibility of damages.
        </p>
        <p>
          Any product or promotion of a product on the Service are not sponsored, endorsed or administered by, or in any other way associated with, Facebook. Facebook has no control over Content, Contributions or other information and opinion expressed via the Service.
        </p>
        <p>
          <strong>Disputes:</strong> If there is any dispute about or involving the Site, you, by using the Site, agree that the dispute will be governed by the laws of the Republic of India without regard to its conflict-of-law provisions. You agree to personal jurisdiction by and venue in New Delhi, in the state of Delhi, India.
        </p>

        <div>
          <p><strong>Unacceptable Content:</strong></p>
          <ul className="list-disc list-inside space-y-2 mt-2">
            <li>Offensive, harmful and/or abusive language, including without limitation: expletives, profanities, obscenities, harassment, vulgarities, sexually explicit language and hate speech (e.g., racist/discriminatory speech.)</li>
            <li>Articles that comment on other users.</li>
            <li>Content that contains personal attacks or describes physical confrontations and/or sexual harassment.</li>
            <li>Excessive damage or death of a puppy bought from a particular kennel club and related cases caused by a business or service to a person or property.</li>
            <li>Personal information or messages including email addresses, URLs, phone numbers and postal addresses.</li>
            <li>Messages that are advertising or commercial in nature, or are inappropriate based on the applicable subject matter.</li>
            <li>Language that violates the standards of good taste or the standards of this website, as determined by Meals.DogSpot.in its sole discretion.</li>
            <li>Content determined by DogSpot Meals to be illegal, or to violate any central, state, or local law or regulation or the rights of any other person or entity.</li>
            <li>Language intended to impersonate other users (including names of other individuals) or offensive or inappropriate user names or signatures.</li>
            <li>Articles which scrape or re-purpose other people's content without permission.</li>
            <li>Protected by copyright or trademark and used, in any manner on Meals.Dog.Spot.in without the permission of the author or the owner;</li>
          </ul>
        </div>

        <p><strong>Defamatory; illegal; hateful; pornographic; or harmful</strong></p>
        
        <p><strong>Note:</strong> We cannot police every details we include on Dogspot Meals, so we will make mistakes. If we've Publis any detail on our site which you feel is misappropriating your content, please let us know at <strong>meals@dogspot.in.</strong> DogSpot Meals team will exercise its discretion on such subjects based on statistics, user feedback.</p>

        <div>
          <p><strong>Copyright</strong></p>
          <p className="mt-2">1. You may not reproduce, publish, perform, broadcast, make an adaptation of, sell, lease, offer or expose any copy of any Content in respect of which we own the copyright without our consent, or in the case of the Content of a third party author, without his or her consent.</p>
          <p className="mt-2">2. You acknowledge that we own the right, title and interest in and to the Services developed and provided by us, the system which provides the Services and all software associated with the Services, as well as all Intellectual Property Rights thereto.</p>
          <p className="mt-2">3. You will comply with all national and international laws pertaining to Intellectual Property Rights.</p>
        </div>

        <div>
            <p><strong>A.  Your content 1.</strong> You will retain ownership of any original content that you provide when using a Service, including any text, data, information, images, photographs, music, sound, video or any other material which you may upload, transmit or store when making use of our Service. <strong>2.</strong> However, we own all compilations, collective works or derivative works created by us which may incorporate your content and which are reduced to a material form and original; and with regards to content which you may upload or make available for inclusion on publicly accessible areas, you grant us an irrevocable, perpetual, worldwide and royalty-free right and license to use, publicly display, publish, publicly perform, reproduce, distribute, broadcast, adapt, modify and promote your content on any medium.</p>
        </div>

        <div>
            <p><strong>B.</strong> Should you be of the view that the Intellectual Property Rights in any of your works uploaded on the Service have been infringed or otherwise violated, please provide our Webmaster with the following information:</p>
            <ul className="list-disc list-inside space-y-2 mt-2">
                <li>A description of the work, which you claim, has been infringed;</li>
                <li>The location of the work on the ibibo.com site;</li>
                <li>Your contact details;</li>
                <li>An affidavit deposed to by you stating that the work was used without your consent;</li>
                <li>Written consent if an agent is acting on your behalf.</li>
                <li>The level of attention to be afforded to your matter will lie within our discretion.</li>
            </ul>
            <p className="mt-2">This clause should in no way be construed as a guarantee that we will assist you under these circumstances.</p>
        </div>
        
        <div>
            <p><strong>Promotional Code Terms & Conditions:</strong></p>
            <ul className="list-disc list-inside space-y-2 mt-2">
                <li>Coupon/Gift Voucher is issued at the sole discretion of Petsglam Services Pvt Ltd (company).</li>
                <li>The company retains the right to revoke, modify and/or alter them as it may deem fit.</li>
                <li>Only one Coupon/Gift Voucher can be used against one particular order.</li>
                <li>Coupon usage is restricted to certain products and/or categories and is subject to change from time to time.</li>
                <li>The company will issue coupons from time to time under various promotions. Members who are eligible for these coupons will be intimated about the same via email, text alert and/or on site messaging.</li>
                <li>All coupons will expire after a set duration and can be used as per the usage defined. This information would be communicated to members.</li>
                <li>Any remainder Coupon amount will lapse.</li>
                <li>Action(s) intended to fraudulently gain Coupons under any promotional scheme or otherwise will result in cancellation of Coupon/Order and/or termination of account.</li>
                <li>Any issue(s) arising with redemption of Coupons will be dealt on a case to case basis. The final decision rests with the company.</li>
                <li>Gift Voucher can be redeemed against purchase(s) on site in full. Any unused amount will be returned back to the account.</li>
                <li>This policy is subject to change from time to time without prior notices.</li>
                <li>In case of any query pertaining to use of Coupon and/or Gift Voucher, please email customer care on meals@dogspot.in.</li>
            </ul>
        </div>
        
        <p><strong>Product Recommendation- Terms and Condition</strong></p>
        <p>All recommendations by the DogSpot Meals team are presented in good faith and believed to be correct to the best of our knowledge. Meals.DogSpot.in requests the customer to use his/her own discretion while making a purchase.</p>

        <div>
            <p><strong>Terms and Conditions for Donation:</strong></p>
            <ul className="list-disc list-inside space-y-2 mt-2">
                <li>Tax Rebate Policy- When you donate through our website, you shall NOT be eligible for any benefits like tax rebate..</li>
                <li>Contribution from DogSpot.in: DogSpot Meals will now match the quantity you choose to donate i.e if you choose 1 packet of dog food, 2 packets will be donated to the concerned person.</li>
                <li>No schemes/discounts available- The ongoing schemes/discounts will not be applicable on donation items.</li>
                <li>Refund policy- If you make an error in your order please contact us either by email at meals@dogspot.in or by Phone at +91-9818011567 within 24 hours and a full refund will be made to you.</li>
                <li>Any item which is once used by the customer, will not be replaced by the seller.</li>
            </ul>
        </div>

        <div>
            <p><strong>Terms and Conditions for Offer period:</strong></p>
            <ul className="list-disc list-inside space-y-2 mt-2">
                <li>DogSpot Meals is not liable for any faulty or incorrect order made by the customers.</li>
                <li>Any operational errors in terms of dispatch and delivery form our end will be complied by Meals.DogSpot.in</li>
                <li>Meals.DogSpot.in reserves all rights to change and or cancel the offer without prior intimation.</li>
                <li>Meals.DogSpot.in reserves right to cancel order without being obliged to give any reason.</li>
            </ul>
        </div>

        <div>
            <p><strong>Electronic communications</strong></p>
            <ul className="list-disc list-inside space-y-2 mt-2">
                <li>When you visit the Site or send emails to us, you are communicating with us electronically.</li>
                <li>You consent to receive communications from us electronically.</li>
                <li>We will communicate with you by email, SMS's or by posting notices on the Site.</li>
                <li>Meals.DogSpot.in reserves all rights to change and or cancel the offer without prior intimation.</li>
                <li>You agree that all agreement notices disclosures and other communications that we provide to you electronically satisfy any legal requirement that such communications be in writing.</li>
            </ul>
        </div>

      </div>
    </div>
  );
}
