import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import Link from 'next/link';
import { Phone, Mail, MapPin, Facebook, Instagram, Twitter, Youtube } from 'lucide-react';

export default function GetInTouchPage() {
  return (
    <div className="container mx-auto py-16 px-4 md:px-6">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight font-headline">Get in Touch</h1>
        <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
          Have questions, comments, or just want to share a cute dog photo? We'd love to hear from you!
        </p>
      </div>
      <div className="max-w-2xl mx-auto">
        <form className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input id="name" placeholder="Your Name" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="your.email@example.com" />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="subject">Subject</Label>
            <Input id="subject" placeholder="What's this about?" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">Message</Label>
            <Textarea id="message" placeholder="Tell us what's on your mind..." rows={6} />
          </div>
          <div className="text-right">
            <Button type="submit" size="lg">Send Message</Button>
          </div>
        </form>

        <Separator className="my-12" />

        <div className="space-y-8">
          <h2 className="text-3xl font-bold text-center font-headline">Contact Information</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-lg">
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <Phone className="h-6 w-6 mt-1 text-primary" />
                <div>
                  <h3 className="font-semibold">Whatsapp & Calls</h3>
                  <a href="tel:+919717625081" className="text-muted-foreground hover:text-primary">+91-9717625081</a>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Mail className="h-6 w-6 mt-1 text-primary" />
                <div>
                  <h3 className="font-semibold">Email</h3>
                  <a href="mailto:meals@dogspot.in" className="text-muted-foreground hover:text-primary">meals@dogspot.in</a>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <MapPin className="h-6 w-6 mt-1 text-primary" />
                <div>
                  <h3 className="font-semibold">Address</h3>
                  <p className="text-muted-foreground">D-04, Super Mart- 2, DLF Phase-4, Gurgaon, Haryana- 122009, India</p>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <h3 className="font-semibold text-xl">Follow Us</h3>
              <p className="text-muted-foreground">@indogspot</p>
              <div className="flex space-x-4">
                  <Link href="https://www.facebook.com/indogspot" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                    <span className="sr-only">Facebook</span>
                    <Facebook className="h-7 w-7" />
                  </Link>
                  <Link href="https://www.instagram.com/indogspot/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                    <span className="sr-only">Instagram</span>
                    <Instagram className="h-7 w-7" />
                  </Link>
                  <Link href="https://x.com/indogspot" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                    <span className="sr-only">Twitter</span>
                    <Twitter className="h-7 w-7" />
                  </Link>
                  <Link href="https://www.youtube.com/indogspot" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                    <span className="sr-only">Youtube</span>
                    <Youtube className="h-7 w-7" />
                  </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}