
import type { Metadata } from 'next';
import './globals.css';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { Toaster } from "@/components/ui/toaster"
import { cn } from '@/lib/utils';
import { ChatWidget } from '@/components/chat-widget';
import { Inter } from 'next/font/google';
import { AuthProvider } from '@/hooks/use-auth';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-body',
});

const headlineFont = Inter({
  subsets: ['latin'],
  weight: ['700'],
  variable: '--font-headline',
});


export const metadata: Metadata = {
  title: 'DogSpot Delights',
  description: 'Premium meals for your beloved dog.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={cn("scroll-smooth", inter.variable, headlineFont.variable)}>
      <head>
      </head>
      <body className={cn(
        'min-h-screen bg-background font-body antialiased'
      )}>
        <AuthProvider>
            <div className="relative flex min-h-dvh flex-col bg-background">
            <Header />
            <main className="flex-1">{children}</main>
            <Footer />
            </div>
            <Toaster />
            <ChatWidget />
        </AuthProvider>
      </body>
    </html>
  );
}
