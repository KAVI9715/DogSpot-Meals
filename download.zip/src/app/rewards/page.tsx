import { Button } from "@/components/ui/button";
import { PawPrint, Gift, Star } from "lucide-react";

export default function RewardsPage() {
  return (
    <div className="container mx-auto py-16 px-4 md:px-6">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight font-headline">DogSpot Rewards</h1>
        <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
          Because a good dog deserves more than just a treat. Earn points, get perks, and spoil your pup!
        </p>
      </div>
      <div className="max-w-4xl mx-auto grid md:grid-cols-3 gap-8 text-center">
        <div className="p-6 bg-card rounded-lg shadow-md">
            <PawPrint className="h-12 w-12 mx-auto text-primary mb-4" />
            <h3 className="text-2xl font-semibold mb-2">Earn Points</h3>
            <p className="text-muted-foreground">Get points for every dollar spent, for following us on social media, and on your pup's birthday!</p>
        </div>
        <div className="p-6 bg-card rounded-lg shadow-md">
            <Gift className="h-12 w-12 mx-auto text-primary mb-4" />
            <h3 className="text-2xl font-semibold mb-2">Redeem Perks</h3>
            <p className="text-muted-foreground">Use your points for discounts on future orders, exclusive toys, and limited-edition swag.</p>
        </div>
        <div className="p-6 bg-card rounded-lg shadow-md">
            <Star className="h-12 w-12 mx-auto text-primary mb-4" />
            <h3 className="text-2xl font-semibold mb-2">VIP Tiers</h3>
            <p className="text-muted-foreground">The more you spoil them, the more we spoil you! Unlock new tiers for even better rewards.</p>
        </div>
      </div>
      <div className="text-center mt-12">
        <Button size="lg">Join the Pack</Button>
      </div>
    </div>
  );
}
