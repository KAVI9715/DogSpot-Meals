import Link from "next/link";

export default function BlogPage() {
  return (
    <div className="container mx-auto py-16 px-4 md:px-6">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight font-headline">The DogSpot Blog</h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Paws for thought. Insights, tips, and stories from our pack to yours.
        </p>
      </div>
      <div className="max-w-3xl mx-auto space-y-8">
        <article className="p-6 bg-card rounded-lg shadow-md">
          <Link href="/blog/feeding-guidelines">
            <h2 className="text-2xl md:text-3xl font-bold font-headline mb-4 hover:text-primary transition-colors">
              Feeding Guidelines - DogSpot Meals
            </h2>
          </Link>
          <p className="text-muted-foreground text-lg">
            DogSpot meals is a complete balanced food for your pet. The food has to be given directly to your pet. No need to heat or to mix anything with it. If your pet is fussy, we recommend starting with a smaller quantity and gradually increasing it. For more detailed instructions, click the link above!
          </p>
        </article>
      </div>
    </div>
  );
}
