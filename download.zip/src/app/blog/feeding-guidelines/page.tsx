import Image from 'next/image';
import { FeedingGuidelinesClient } from './feeding-guidelines-client';

export default function FeedingGuidelinesPage() {
  return (
    <div className="container mx-auto py-16 px-4 md:px-6">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight font-headline">
            Feeding Guidelines - DogSpot Meals
          </h1>
        </div>
        <div className="space-y-8 text-lg text-muted-foreground">
          <ul className="list-disc list-inside space-y-4">
            <li>
              DogSpot meals is a complete balanced food for your pet. The food has to be given directly to your pet. No need to heat or to mix anything with it.
            </li>
            <li>
              Heating is required only in extremely cold weather. You can add little hot water to enhance the aroma.
            </li>
            <li>
              The following feeding quantities, in the table, are approximate. A body weight range has been indicated. Daily intake may vary based on activity levels and other factors such as weather, mental stress etc.
            </li>
          </ul>
          <div className="flex justify-center">
            <Image 
              src="https://cdn.shopify.com/s/files/1/0583/2930/1183/files/Screenshot_2022-11-30_at_5.35.07_PM_3a1211ce-1844-49b3-9776-e7870f5520eb_480x480.png?v=1669810345" 
              alt="Feeding guidelines table"
              data-ai-hint="feeding guidelines"
              width={480} 
              height={480}
              className="rounded-lg shadow-lg"
            />
          </div>
          <div className="text-center mt-8">
            <FeedingGuidelinesClient />
          </div>
        </div>
      </div>
    </div>
  );
}
