'use client';

import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Share2, Link, Mail, MessageCircle, Twitter, Facebook, Linkedin } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export function FeedingGuidelinesClient() {
    const { toast } = useToast();
    const pageUrl = typeof window !== 'undefined' ? window.location.href : '';
    const shareText = "Check out these feeding guidelines from DogSpot Meals!";

    const socialShares = [
        { name: 'WhatsApp', icon: MessageCircle, url: `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText + ' ' + pageUrl)}` },
        { name: 'Gmail', icon: Mail, url: `mailto:?subject=${encodeURIComponent(shareText)}&body=${encodeURIComponent(pageUrl)}` },
        { name: 'Facebook', icon: Facebook, url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(pageUrl)}` },
        { name: 'Twitter', icon: Twitter, url: `https://twitter.com/intent/tweet?url=${encodeURIComponent(pageUrl)}&text=${encodeURIComponent(shareText)}` },
        { name: 'LinkedIn', icon: Linkedin, url: `https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(pageUrl)}&title=${encodeURIComponent(shareText)}` },
    ];

    const handleCopy = () => {
        navigator.clipboard.writeText(pageUrl);
        toast({
            title: "Link Copied!",
            description: "The page link has been copied to your clipboard.",
        });
    };

    const handleNativeShare = () => {
        if (navigator.share) {
            navigator.share({
                title: 'DogSpot Feeding Guidelines',
                text: shareText,
                url: pageUrl,
            })
            .then(() => console.log('Successful share'))
            .catch((error) => console.log('Error sharing', error));
        } else {
            // Fallback for browsers that do not support native share
            // This will open the dialog
        }
    }


    return (
        <Dialog>
            <DialogTrigger asChild>
                <Button variant="outline">
                    <Share2 className="mr-2 h-4 w-4" />
                    Share
                </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
                <DialogHeader>
                    <DialogTitle>Share these Guidelines</DialogTitle>
                    <DialogDescription>
                        Help other pet parents by sharing these helpful feeding guidelines.
                    </DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 py-4">
                    {socialShares.map(({ name, icon: Icon, url }) => (
                         <a key={name} href={url} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-2 p-3 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors">
                            <Icon className="h-6 w-6" />
                            <span>{name}</span>
                        </a>
                    ))}
                    {navigator.share && (
                         <button onClick={handleNativeShare} className="flex flex-col items-center gap-2 p-3 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors">
                            <Share2 className="h-6 w-6" />
                            <span>Nearby Share</span>
                        </button>
                    )}
                </div>
                <div className="flex items-center space-x-2">
                    <div className="grid flex-1 gap-2">
                        <input
                            id="link"
                            defaultValue={pageUrl}
                            readOnly
                            className="h-9 flex-1 rounded-md border border-input bg-background px-3 text-sm"
                        />
                    </div>
                    <Button type="button" size="sm" className="px-3" onClick={handleCopy}>
                        <span className="sr-only">Copy</span>
                        <Link className="h-4 w-4" />
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
}
