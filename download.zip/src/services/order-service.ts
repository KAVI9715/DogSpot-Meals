
'use server';

import { collection, getDocs, doc, setDoc, serverTimestamp, orderBy, query, QueryDocumentSnapshot, DocumentData, addDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { CartItem } from '@/hooks/use-cart';

export interface Order {
    id: string;
    customer: {
        firstName: string;
        lastName: string;
        email: string;
        address: string;
        city: string;
        zip: string;
    };
    items: CartItem[];
    total: number;
    status: 'Pending' | 'Paid' | 'Shipped' | 'Delivered' | 'Cancelled';
    createdAt: string; // ISO string date
}

const fromFirestore = (doc: QueryDocumentSnapshot<DocumentData>): Order => {
    const data = doc.data();
    // Firestore timestamp to ISO string conversion
    const createdAt = data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString();
    return {
        id: doc.id,
        customer: data.customer,
        items: data.items,
        total: data.total,
        status: data.status,
        createdAt: createdAt,
    };
};

export const createOrder = async (orderData: Omit<Order, 'id' | 'createdAt' | 'status'>): Promise<string | null> => {
    if (!db) {
      console.error("Firebase not configured, cannot create order.");
      // In a real app, you might want to throw an error that you can catch in the UI.
      // For this context, returning null is sufficient to indicate failure.
      return null;
    };
    
    const ordersCollection = collection(db, 'orders');
    
    const newOrder = {
        ...orderData,
        status: 'Paid', // Assuming payment is instant
        createdAt: serverTimestamp(),
    }

    try {
        const newDocRef = await addDoc(ordersCollection, newOrder);
        return newDocRef.id;
    } catch (error) {
        console.error("Error creating order:", error);
        // Similar to the above, you could handle this more gracefully in the UI.
        return null;
    }
};


export const getOrders = async (): Promise<Order[]> => {
    if (!db) {
        console.warn("Firebase not configured, cannot get orders.");
        return [];
    };
    try {
        const ordersCollection = collection(db, 'orders');
        const q = query(ordersCollection, orderBy('createdAt', 'desc'));
        const snapshot = await getDocs(q);
        return snapshot.docs.map(fromFirestore);
    } catch (error) {
        console.error("Error fetching orders:", error);
         if (error instanceof Error && error.message.includes('offline')) {
            console.warn('Firestore is offline, returning empty orders list.');
            return [];
        }
        // For other errors, return empty array to prevent crashing pages that use this.
        return [];
    }
};
