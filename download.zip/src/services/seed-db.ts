
'use server';

import { writeBatch, collection, doc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { products, slideshowImages, collectionImages, featuredRecipes, multicolumnItems } from '@/lib/data';

export async function seedDatabase() {
  if (!db) {
    const message = 'Firebase is not configured. Please use the chat widget to connect your Firebase project before seeding the database.';
    console.error(message);
    return { success: false, message };
  }
  
  const batch = writeBatch(db);
  
  // Seed products
  const productsCollection = collection(db, 'products');
  products.forEach((product) => {
    const docRef = doc(productsCollection); 
    batch.set(docRef, product);
  });

  // Seed site content
  const siteContentData = {
    slideshowImages,
    collectionImages,
    featuredRecipes,
    multicolumnItems
  };
  const siteContentDocRef = doc(db, 'siteContent', 'homepage');
  batch.set(siteContentDocRef, siteContentData);


  try {
    await batch.commit();
    return { success: true, message: `${products.length} products and homepage content have been successfully seeded.` };
  } catch (error) {
    console.error("Error seeding database: ", error);
    if (error instanceof Error) {
        if (error.message.includes('offline')) {
             return { success: false, message: `Error seeding database: The client is offline. Please check your network connection and Firebase project configuration.` };
        }
        return { success: false, message: `Error seeding database: ${error.message}` };
    }
    return { success: false, message: 'An unknown error occurred while seeding the database.' };
  }
}
