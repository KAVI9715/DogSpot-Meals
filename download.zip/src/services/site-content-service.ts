
'use server';

import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { slideshowImages, collectionImages, featuredRecipes, multicolumnItems } from '@/lib/data';

export interface SlideshowImage {
  src: string;
  alt: string;
  hint: string;
  link: string;
  title?: string;
  description?: string;
}

export interface CollectionImage {
  src: string;
  alt: string;
  category: string;
  hint: string;
}

export interface FeaturedRecipe {
  name: string;
  image: string;
  hint: string;
}

export interface MulticolumnItem {
  name: string;
  image: string;
  hint: string;
  hasArrow?: boolean;
  link?: string;
}

export interface SiteContent {
  slideshowImages: SlideshowImage[];
  collectionImages: CollectionImage[];
  featuredRecipes: FeaturedRecipe[];
  multicolumnItems: MulticolumnItem[];
}

const defaultSiteContent: SiteContent = {
  slideshowImages,
  collectionImages,
  featuredRecipes,
  multicolumnItems,
};


export const getSiteContent = async (): Promise<SiteContent> => {
    if (!db) {
        console.warn('Firebase not configured. Using default site content.');
        return defaultSiteContent;
    }

    try {
        const docRef = doc(db, 'siteContent', 'homepage');
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
            return docSnap.data() as SiteContent;
        } else {
            console.warn("Homepage content document not found in Firestore. Using default data and attempting to seed.");
            await updateSiteContent(defaultSiteContent);
            return defaultSiteContent;
        }
    } catch (error) {
        console.error("Error fetching site content from Firestore:", error);
         if (error instanceof Error && error.message.includes('offline')) {
            console.warn('Firestore is offline, returning default site content.');
            return defaultSiteContent;
        }
        // For other errors, you might want to rethrow or handle differently
        // but for now, we return default content to prevent site crash.
        return defaultSiteContent;
    }
};

export const updateSiteContent = async (content: Partial<SiteContent>): Promise<void> => {
    if (!db) {
        console.error("Firebase not configured. Cannot update site content.");
        return;
    };
    const docRef = doc(db, 'siteContent', 'homepage');
    await setDoc(docRef, content, { merge: true });
};
