
'use server';

import { collection, getDocs, doc, getDoc, setDoc, deleteDoc, DocumentData, QueryDocumentSnapshot, addDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { products as defaultProducts } from '@/lib/data';

export interface Product {
    id: string;
    name: string;
    price: number;
    category: 'Small' | 'Medium' | 'Indie Special' | 'Large' | 'Giant' | 'Trial';
    image1: string;
    image2: string;
    image1Hint: string;
    image2Hint: string;
    description: string;
    feedingGuideImage?: string;
}

const fromFirestore = (doc: QueryDocumentSnapshot<DocumentData>): Product => {
    const data = doc.data();
    return {
        id: doc.id,
        name: data.name,
        price: data.price,
        category: data.category,
        image1: data.image1,
        image2: data.image2,
        image1Hint: data.image1Hint,
        image2Hint: data.image2Hint,
        description: data.description,
        feedingGuideImage: data.feedingGuideImage,
    };
};

export const getProducts = async (): Promise<Product[]> => {
    if (!db) {
        console.warn('Firebase not configured, returning default products.');
        return defaultProducts.map((p, i) => ({ ...p, id: i.toString() }));
    }
    try {
        const productsCollection = collection(db, 'products');
        const snapshot = await getDocs(productsCollection);
        if (snapshot.empty) {
            console.log('No products in DB, returning default products.');
            return defaultProducts.map((p, i) => ({ ...p, id: i.toString() }));
        }
        return snapshot.docs.map(fromFirestore);
    } catch (error) {
        console.error("Error fetching products from Firestore:", error);
        if (error instanceof Error && error.message.includes('offline')) {
            console.warn('Firestore is offline, returning default products.');
            return defaultProducts.map((p, i) => ({ ...p, id: i.toString() }));
        }
        // Fallback for other potential errors during initial setup
        return defaultProducts.map((p, i) => ({ ...p, id: i.toString() }));
    }
};

export const getProductById = async (id: string): Promise<Product | null> => {
    if (!db) {
        console.warn('Firebase not configured, returning default product.');
        const localProduct = defaultProducts.find((p, i) => i.toString() === id);
        return localProduct ? { ...localProduct, id } : null;
    }
    try {
        const docRef = doc(db, 'products', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
            // The type assertion here is safe because we check for existence.
            return { id: docSnap.id, ...docSnap.data() } as Product;
        }
        return null;
    } catch (error) {
        console.error(`Error fetching product ${id} from Firestore:`, error);
        if (error instanceof Error && error.message.includes('offline')) {
             console.warn(`Firestore is offline, returning default product for id ${id}.`);
             const localProduct = defaultProducts.find((p, i) => i.toString() === id);
             return localProduct ? { ...localProduct, id } : null;
        }
        // Fallback for other potential errors
        const localProduct = defaultProducts.find((p, i) => i.toString() === id);
        return localProduct ? { ...localProduct, id } : null;
    }
};

export const createProduct = async (productData: Omit<Product, 'id'>): Promise<string | null> => {
    if (!db) return null;
    const productsCollection = collection(db, 'products');
    const docRef = await addDoc(productsCollection, productData);
    return docRef.id;
};

export const updateProduct = async (id: string, productData: Partial<Product>): Promise<void> => {
    if (!db) return;
    const docRef = doc(db, 'products', id);
    await setDoc(docRef, productData, { merge: true });
};

export const deleteProduct = async (id: string): Promise<void> => {
    if (!db) return;
    const docRef = doc(db, 'products', id);
    await deleteDoc(docRef);
};
