
import { NextResponse, type NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname;
  const isAdminLoginPath = path === '/admin/login';
  const token = request.cookies.get('auth_token')?.value;

  // If trying to access admin pages (except login) without a token, redirect to admin login
  if (path.startsWith('/admin') && !isAdminLoginPath && !token) {
    return NextResponse.redirect(new URL('/admin/login', request.nextUrl));
  }

  // If logged in and trying to access admin login page, redirect to admin dashboard
  if (isAdminLoginPath && token) {
    return NextResponse.redirect(new URL('/admin', request.nextUrl));
  }

  return NextResponse.next();
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: ['/admin/:path*', '/admin/login', '/login'],
};
