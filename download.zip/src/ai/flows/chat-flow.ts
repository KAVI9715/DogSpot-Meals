'use server';
/**
 * @fileOverview A conversational AI flow for customer support.
 *
 * - chat - A function that handles the chat conversation.
 */

import {ai} from '@/ai/genkit';
import { ChatInputSchema, ChatOutputSchema, type ChatInput, type ChatOutput } from '@/ai/schemas/chat-schemas';

export async function chat(input: ChatInput): Promise<ChatOutput> {
  return chatFlow(input);
}

const chatFlow = ai.defineFlow(
  {
    name: 'chatFlow',
    inputSchema: ChatInputSchema,
    outputSchema: ChatOutputSchema,
  },
  async ({ history, newMessage }) => {
    const chatHistory = history.map(msg => ({
      role: msg.role,
      content: [{ text: msg.content }],
    }));

    const response = await ai.generate({
      model: 'googleai/gemini-2.5-flash',
      history: chatHistory,
      prompt: newMessage,
      system: `You are a friendly and helpful customer service assistant for DogSpot Delights, an online store that sells premium, healthy dog food.

Your goal is to answer customer questions, provide information about products, and help with orders. Be polite, concise, and knowledgeable.

Here is some information about the store and products:
- The store is called DogSpot Delights.
- They sell high-quality, human-grade dog food.
- Key selling points are: no preservatives, slow-steamed cooking, and natural ingredients like chicken, pumpkin, carrots, and turmeric.
- They offer a 100% money-back guarantee if a pet doesn't eat the food.
- They have different formulas for small, medium, large, and giant breeds, as well as an "Indie Special" for Indian Pariah dogs.
- Customers can find detailed product information, including ingredients and feeding guidelines, on the product pages.
- The company was founded by Rana Atheya, a long-time pet enthusiast, to provide healthier food options than commercially available kibble.

When asked about topics outside of DogSpot Delights or dog food, politely decline to answer and steer the conversation back to the store's products and services.`,
    });

    return { response: response.text };
  }
);
