'use server';

/**
 * @fileOverview A flow that suggests similar product categories using generative AI.
 *
 * - suggestSimilarCategories - A function that suggests similar product categories based on the given category.
 * - SuggestSimilarCategoriesInput - The input type for the suggestSimilarCategories function.
 * - SuggestSimilarCategoriesOutput - The return type for the suggestSimilarCategories function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestSimilarCategoriesInputSchema = z.object({
  category: z.string().describe('The product category to find similar categories for.'),
});
export type SuggestSimilarCategoriesInput = z.infer<typeof SuggestSimilarCategoriesInputSchema>;

const SuggestSimilarCategoriesOutputSchema = z.object({
  suggestions: z.array(z.string()).describe('An array of similar product category suggestions.'),
});
export type SuggestSimilarCategoriesOutput = z.infer<typeof SuggestSimilarCategoriesOutputSchema>;

export async function suggestSimilarCategories(input: SuggestSimilarCategoriesInput): Promise<SuggestSimilarCategoriesOutput> {
  return suggestSimilarCategoriesFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestSimilarCategoriesPrompt',
  input: {schema: SuggestSimilarCategoriesInputSchema},
  output: {schema: SuggestSimilarCategoriesOutputSchema},
  prompt: `You are an expert in product categorization.

  Given the product category "{{category}}", suggest three similar product categories that a user might be interested in. Return the suggestions as a JSON array of strings.
  `,
});

const suggestSimilarCategoriesFlow = ai.defineFlow(
  {
    name: 'suggestSimilarCategoriesFlow',
    inputSchema: SuggestSimilarCategoriesInputSchema,
    outputSchema: SuggestSimilarCategoriesOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
