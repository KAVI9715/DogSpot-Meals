'use server';

/**
 * @fileOverview A flow to highlight customer reviews that are emotionally charged and exciting using generative AI.
 *
 * - highlightExcitingReviews - A function that filters and highlights reviews based on emotional charge.
 * - HighlightExcitingReviewsInput - The input type for the highlightExcitingReviews function.
 * - HighlightExcitingReviewsOutput - The return type for the highlightExcitingReviews function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const HighlightExcitingReviewsInputSchema = z.object({
  reviews: z.array(z.string()).describe('An array of customer review strings.'),
});
export type HighlightExcitingReviewsInput = z.infer<typeof HighlightExcitingReviewsInputSchema>;

const HighlightExcitingReviewsOutputSchema = z.object({
  highlightedReviews: z.array(z.string()).describe('An array of customer reviews that are emotionally charged and exciting.'),
});
export type HighlightExcitingReviewsOutput = z.infer<typeof HighlightExcitingReviewsOutputSchema>;

export async function highlightExcitingReviews(input: HighlightExcitingReviewsInput): Promise<HighlightExcitingReviewsOutput> {
  return highlightExcitingReviewsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'highlightExcitingReviewsPrompt',
  input: {schema: HighlightExcitingReviewsInputSchema},
  output: {schema: HighlightExcitingReviewsOutputSchema},
  prompt: `You are an AI assistant that identifies emotionally charged and exciting customer reviews from a given list.

  Reviews:
  {{#each reviews}}
  - "{{this}}"
  {{/each}}

  Identify the reviews that express strong emotions (excitement, enthusiasm, delight) towards the product or service. These reviews should indicate that the customer is extremely pleased or impressed.
  Return ONLY an array containing these highlighted reviews. Do not include any additional text or explanations.
  If there are no reviews that meet the emotional criteria, return an empty array.
  The output MUST be a JSON array of strings.
  `,
});

const highlightExcitingReviewsFlow = ai.defineFlow(
  {
    name: 'highlightExcitingReviewsFlow',
    inputSchema: HighlightExcitingReviewsInputSchema,
    outputSchema: HighlightExcitingReviewsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
