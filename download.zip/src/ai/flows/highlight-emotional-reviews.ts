'use server';

/**
 * @fileOverview A flow to highlight customer reviews that are emotionally charged and positive using generative AI.
 *
 * - highlightEmotionalReviews - A function that filters and highlights reviews based on emotional charge.
 * - HighlightEmotionalReviewsInput - The input type for the highlightEmotionalReviews function.
 * - HighlightEmotionalReviewsOutput - The return type for the highlightEmotionalReviews function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const HighlightEmotionalReviewsInputSchema = z.object({
  reviews: z.array(z.string()).describe('An array of customer review strings.'),
});
export type HighlightEmotionalReviewsInput = z.infer<typeof HighlightEmotionalReviewsInputSchema>;

const HighlightEmotionalReviewsOutputSchema = z.object({
  highlightedReviews: z.array(z.string()).describe('An array of customer reviews that are emotionally charged and positive.'),
});
export type HighlightEmotionalReviewsOutput = z.infer<typeof HighlightEmotionalReviewsOutputSchema>;

export async function highlightEmotionalReviews(input: HighlightEmotionalReviewsInput): Promise<HighlightEmotionalReviewsOutput> {
  return highlightEmotionalReviewsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'highlightEmotionalReviewsPrompt',
  input: {schema: HighlightEmotionalReviewsInputSchema},
  output: {schema: HighlightEmotionalReviewsOutputSchema},
  prompt: `You are an AI assistant that identifies emotionally charged and positive customer reviews from a given list.

  Reviews:
  {{#each reviews}}
  - "{{this}}"
  {{/each}}

  Identify the reviews that express strong positive emotions (excitement, satisfaction, delight) towards the product or service.
  Return ONLY an array containing these highlighted reviews. Do not include any additional text or explanations.
  If there are no reviews that meet the emotional criteria, return an empty array.
  The output MUST be a JSON array of strings.
  `,
});

const highlightEmotionalReviewsFlow = ai.defineFlow(
  {
    name: 'highlightEmotionalReviewsFlow',
    inputSchema: HighlightEmotionalReviewsInputSchema,
    outputSchema: HighlightEmotionalReviewsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
