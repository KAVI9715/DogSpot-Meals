/**
 * @fileOverview Schemas and types for the chat flow.
 *
 * - ChatInputSchema - The Zod schema for the chat function input.
 * - ChatInput - The TypeScript type for the chat function input.
 * - ChatOutputSchema - The Zod schema for the chat function output.
 * - ChatOutput - The TypeScript type for the chat function output.
 */

import { z } from 'genkit';

export const ChatInputSchema = z.object({
  history: z.array(z.object({
    role: z.enum(['user', 'model']),
    content: z.string(),
  })).describe('The conversation history.'),
  newMessage: z.string().describe('The new message from the user.'),
});
export type ChatInput = z.infer<typeof ChatInputSchema>;

export const ChatOutputSchema = z.object({
  response: z.string().describe("The AI's response."),
});
export type ChatOutput = z.infer<typeof ChatOutputSchema>;
