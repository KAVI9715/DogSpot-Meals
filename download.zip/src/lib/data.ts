

export type Product = {
  id: number;
  name: string;
  price: number;
  category: 'Small' | 'Medium' | 'Indie Special' | 'Large' | 'Giant' | 'Trial';
  image1: string;
  image2: string;
  image1Hint: string;
  image2Hint: string;
  description: string;
  feedingGuideImage?: string;
};

const detailedDescription = `<p>DogSpot Meals is a ready to eat, complete meal for dogs. We make DogSpot Meals by a gentle steam cooking process. The proportion of chicken is the highest among all the ingredients.</p>
<ul>
    <li>No added preservatives or chemicals. No refrigeration required. Slow steam cooking process, that helps sterilisation of food</li>
    <li>Human grade ingredients: Made with Chicken, Rice, Pumpkin, Carrot, Coconut Oil, Turmeric Extract & Water</li>
    <li>Transparent & Honest Food: You can see, smell and even eat to check the ingredients yourself</li>
    <li>Natural & Made in India: Made with ingredients you would find in your own kitchen. Globally accepted dog food recipe Made in India</li>
    <li>Best Before: Best before 12 months from the date of manufacturing even when stored at room temperature</li>
    <li>100% money back guarantee. If your pet doesn't eat DogSpot Meal, we will take the unused food back and refund the money. No questions asked</li>
    <li>Environment friendly Packing: 100% recyclable pouch and packaging</li>
</ul>

<h4>Health Benefits & Ingredients:</h4>
<h5>Chicken:</h5>
<p>We source high quality human grade chicken, rich in proteins, fat, minerals and vitamins. Dogs need protein as their main source of energy; chicken is known to be one of the best sources of protein and helps dogs to build lean muscle mass. Omega 6 Fatty Acids are required for a dog’s healthy skin and shiny coat, which is present in chicken. Chicken is a great source of essential amino acids for dogs.</p>

<h5>Pumpkin:</h5>
<p>Pumpkin is a superfood for dogs. It is a good source of essential Vitamins, Minerals and fibre. Besides being a natural stomach soother, pumpkin also helps to remove excess water in a dog's digestive tract and reduces diarrhoea. Pumpkin also works as a great prebiotic.</p>

<h5>Carrot:</h5>
<p>Carrot is a great source of Vitamin A. There are two types of Vitamin A: Retinoids and Carotenoids Carrots are rich in fibre and Beta-Carotene. Beta-Carotene has antioxidative properties and is a precursor to Vitamin A (dogs convert Beta Carotene into Vitamin A (Retinol). It provides support for eye, skin, & coat health and a thriving immune system.</p>

<h5>Coconut Oil:</h5>
<p>Coconut oil is high in saturated fat and medium-chain triglycerides. Medium chain triglycerides are good fats that are beneficial for the immune system, digestive system, skin, and cognitive functions. Coconut oil is easier to digest, so the body can use it efficiently. Lauric Acid, present in coconut oil, has immune-boosting benefits. Feeding Coconut oil in the right amount to dogs is good for their hair, skin, digestive system, immune system and endocrine system.</p>

<h5>Rice:</h5>
<p>Rice, besides providing the daily dose of carbohydrates, provides many health benefits for dogs. Antioxidants in rice defend against diseases and prevent cognitive dysfunction in ageing pets. It soothes the gut during gastrointestinal upsets. Carbohydrates boost energy levels and improve cognitive function.</p>

<h5>Turmeric Extract (Curcumin):</h5>
<p>Turmeric has antioxidant, anti-inflammatory, anti-viral, anti-bacterial, anti-fungal, wound healing and anti-cancer properties. It helps fight diseases like arthritis, diabetes, cancer, liver disease, gastrointestinal issues and more. It is also known to promote healthy joints. Turmeric is a powerful antioxidant. It neutralises free radicals on its own but also stimulates your pet’s body’s own antioxidant enzymes and hence is a great immunity booster.<br/><br/>In DogSpot Meals’ Chicken and Pumpkin Recipe, we use all-natural, standardised, water-dispersible turmeric extract. It has an optimised higher absorption/bioavailability of curcumin.</p>

<h4>Storage:</h4>
<ul>
    <li>Store the sealed pouch in a dry and cool place</li>
    <li>Open pouch should be stored fridge (around 2-5°C) and should be consumed within 12 hours</li>
</ul>

<h4>Feeding Guidelines:</h4>
<ul>
    <li>The food has to be given directly to your pet. No need to heat or to mix anything with it. It is complete food</li>
    <li>Heating is required only in extremely cold weather. You can add little hot water to enhance the aroma</li>
    <li>The following feeding quantities, in the table, are approximate. A body weight range has been indicated. Daily intake may vary based on activity levels and other factors such as weather, mental stress etc.</li>
</ul>
<h4>Nutritional Analysis (Per 100g Food):</h4>
<p>Protein 13%, Fat 11%, Fibre 1.5%, Moisture 70%, Energy- 178 Kcal</p>

<h4>Other Important Instructions:</h4>
<ul>
    <li>Do Not Use the pouch if the pouch is leaking or puffed</li>
    <li>Pouch ingredients should be consumed immediately. Open pouch should be stored under refrigeration (around 2-5 degree celsius)</li>
    <li>Store the sealed pouch in a dry and cool place</li>
</ul>`;

const feedingGuideImage = 'https://cdn.shopify.com/s/files/1/0583/2930/1183/files/Screenshot_2022-05-18_at_4.35.24_PM_480x480.png?v=1652871979';


export const products: Omit<Product, 'id'>[] = [
    {
        name: 'Chicken and Rice with Goodness of Curcumin - Trial Pack',
        price: 299.00,
        category: 'Trial',
        image1: 'https://meals.dogspot.in/cdn/shop/products/BoxPacking.png?v=1683804421',
        image2: 'https://m.media-amazon.com/images/I/61CPg6tFe3L._UF350,350_QL80_.jpg',
        image1Hint: 'dog food box',
        image2Hint: 'dog food pack',
        description: detailedDescription,
        feedingGuideImage: feedingGuideImage,
    },
    {
        name: 'Chicken and Rice with Goodness of Curcumin - Food for Large Breed',
        price: 2759.00,
        category: 'Large',
        image1: 'https://meals.dogspot.in/cdn/shop/files/8x75_adbe5f03-7346-484b-a484-2754ef4e10fe.png?v=1683805956&width=1445',
        image2: 'https://meals.dogspot.in/cdn/shop/products/6_258b2c42-7fca-4ccc-ab7d-661b5585a8aa.jpg?v=1683804421&width=1445',
        image1Hint: 'dog food pack',
        image2Hint: 'dog food meal',
        description: detailedDescription,
        feedingGuideImage: feedingGuideImage,
    },
    {
        name: 'Chicken and Rice with Goodness of Curcumin - Food for Medium Breed',
        price: 1499.00,
        category: 'Medium',
        image1: 'https://meals.dogspot.in/cdn/shop/files/8x75_adbe5f03-7346-484b-a484-2754ef4e10fe.png?v=1683805956&width=1445',
        image2: 'https://meals.dogspot.in/cdn/shop/products/6_25b2c42-7fca-4ccc-ab7d-661b5585a8aa.jpg?v=1683804421&width=1445',
        image1Hint: 'dog food pack',
        image2Hint: 'dog food meal',
        description: detailedDescription,
        feedingGuideImage: feedingGuideImage,
    },
    {
        name: 'Chicken and Rice with Goodness of Curcumin - Food for Indie-Special Breed',
        price: 1899.00,
        category: 'Indie Special',
        image1: 'https://meals.dogspot.in/cdn/shop/files/8x75_adbe5f03-7346-484b-a484-2754ef4e10fe.png?v=1683805956&width=1445',
        image2: 'https://meals.dogspot.in/cdn/shop/products/2_845d7c87-6b55-4a8d-be5f-58390ec12501.jpg?v=1655285529&width=493',
        image1Hint: 'dog food pack',
        image2Hint: 'dog food meal',
        description: detailedDescription,
        feedingGuideImage: feedingGuideImage,
    },
    {
        name: 'Chicken and Rice with Goodness of Curcumin - Food for Small Breed',
        price: 1499.00,
        category: 'Small',
        image1: 'https://meals.dogspot.in/cdn/shop/files/8x75_adbe5f03-7346-484b-a484-2754ef4e10fe.png?v=1683805956&width=1445',
        image2: 'https://meals.dogspot.in/cdn/shop/products/6_258b2c42-7fca-4ccc-ab7d-661b5585a8aa.jpg?v=1683804421&width=1445',
        image1Hint: 'dog food pack',
        image2Hint: 'dog food meal',
        description: detailedDescription,
        feedingGuideImage: feedingGuideImage,
    },
    {
        name: 'Chicken and Rice with Goodness of Curcumin - Food for XS Breed',
        price: 792.00,
        category: 'Small',
        image1: 'https://meals.dogspot.in/cdn/shop/files/8x75_adbe5f03-7346-484b-a484-2754ef4e10fe.png?v=1683805956&width=1445',
        image2: 'https://meals.dogspot.in/cdn/shop/products/6_258b2c42-7fca-4ccc-ab7d-661b5585a8aa.jpg?v=1683804421&width=1445',
        image1Hint: 'dog food pack',
        image2Hint: 'dog food meal',
        description: detailedDescription,
        feedingGuideImage: feedingGuideImage,
    },
    {
        name: 'Fish and Rice with Goodness of Ashwagandha',
        price: 2392.00,
        category: 'Giant',
        image1: 'https://meals.dogspot.in/cdn/shop/files/8x75_adbe5f03-7346-484b-a484-2754ef4e10fe.png?v=1683805956&width=1445',
        image2: 'https://meals.dogspot.in/cdn/shop/products/6_258b2c42-7fca-4ccc-ab7d-661b5585a8aa.jpg?v=1683804421&width=1445',
        image1Hint: 'dog food pack',
        image2Hint: 'dog food meal',
        description: detailedDescription,
        feedingGuideImage: feedingGuideImage,
    },
    {
        name: 'Chicken Grain Free with Goodness of Curcumin',
        price: 1899.00,
        category: 'Trial',
        image1: 'https://meals.dogspot.in/cdn/shop/products/BoxPacking.png?v=1683804421',
        image2: 'https://m.media-amazon.com/images/I/61CPg6tFe3L._UF350_350_QL80_.jpg',
        image1Hint: 'dog food box',
        image2Hint: 'dog food pack',
        description: detailedDescription,
        feedingGuideImage: feedingGuideImage,
    },
    {
        name: 'Chicken and Rice with Goodness of Curcumin - Food for Giant Breed',
        price: 4399.00,
        category: 'Giant',
        image1: 'https://meals.dogspot.in/cdn/shop/files/8x75_adbe5f03-7346-484b-a484-2754ef4e10fe.png?v=1683805956&width=1445',
        image2: 'https://meals.dogspot.in/cdn/shop/products/6_258b2c42-fca-4ccc-ab7d-661b5585a8aa.jpg?v=1683804421&width=1445',
        image1Hint: 'dog food pack',
        image2Hint: 'dog food meal',
        description: detailedDescription,
        feedingGuideImage: feedingGuideImage,
    },
    {
        name: 'Chicken Gravy with Goodness of Curcumin',
        price: 1199.00,
        category: 'Large',
        image1: 'https://meals.dogspot.in/cdn/shop/files/8x75_adbe5f03-7346-484b-a484-2754ef4e10fe.png?v=1683805956&width=1445',
        image2: 'https://meals.dogspot.in/cdn/shop/products/6_258b2c42-fca-4ccc-ab7d-661b5585a8aa.jpg?v=1683804421&width=1445',
        image1Hint: 'dog food pack',
        image2Hint: 'dog food meal',
        description: detailedDescription,
        feedingGuideImage: feedingGuideImage,
    }
];

export const productCategories: Product['category'][] = ['Small', 'Medium', 'Indie Special', 'Large', 'Giant'];

export const categoryDescriptions = {
  'Small': `DogSpot Meals is super convenient for you to serve it to your pooches. One pouch = one meal. We have different pouch sizes. If you have a small size dog (upto 10 Kgs in weight) you can choose 75 g pouch for extra small pooches and 100 g for a little less pooches. We recommend 2 meals a day. That means for extra small size dog you need to feed 150 g a day (75g x 2).\n\nThis collection is good to start from breeds like Chihuahua, Pomeranian, Miniature Pinscher, Yorkshire Terrier and goes up to Pug, Tibetan Spaniel etc`,
  'Medium': `DogSpot Meals is super convenient for you to serve it to your pooches. One pouch = one meal. We have different pouch sizes for your convenience. If you have a medium size dog (around 15Kg in weight) you can choose 150g pouch or a 200g pouch. We recommend 2 meals a day. For example if you have a English Cocker Spaniel weighing about 15Kg you will have to feed 150 g pouch in one meal, twice a day it will be 300g. Please refer to the feeding guidelines provided on the product pages. This collection is good for breeds like Cocker Spaniels, Beagle, French Bulldog etc`,
  'Indie Special': `This collection is specially formulated for our beloved Indie dogs. Given their diverse genetics and active lifestyles, we recommend a balanced diet that supports their high energy levels. A 200g or 300g pouch twice a day is a great starting point, depending on their size and activity. Please refer to the feeding guidelines on the product pages for more specific recommendations.`,
  'Large': `For our large breed companions (25-40 kgs) like Labradors, Golden Retrievers, and German Shepherds, we offer larger meal pouches of 300g and 400g. These meals are designed to support joint health and provide the sustained energy that larger dogs need. Two meals per day are recommended for optimal nutrition.`,
  'Giant': `Our gentle giants, such as Great Danes and Saint Bernards, have unique nutritional needs. This collection features our largest portions (400g and 500g pouches) with added nutrients to support bone strength and a healthy heart. Always consult the feeding guide to ensure your giant friend is getting the right amount.`
};

export const slideshowImages = [
  { 
    src: 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?q=80&w=2669&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', 
    alt: 'Happy dog with promotional text', 
    hint: 'happy dog', 
    link: '/products',
    title: 'Healthy Food for Every Dog',
    description: 'No Preservatives or Chemicals<br>No Refrigeration Required<br>Human Grade<br>Free Shipping<br>30% OFF on your first order. Use Coupon code <b>DSM30</b>'
  },
  { 
    src: 'https://i.postimg.cc/GhbJ44S0/1234567.avif', 
    alt: 'Happy dog with owner', 
    hint: 'happy dog', 
    link: '/rewards' 
  },
  { 
    src: 'https://meals.dogspot.in/cdn/shop/files/Untitled_design.png?height=628&pad_color=fcfcfc&v=1653964091&width=1200', 
    alt: 'A variety of DogSpot meals', 
    hint: 'dog food products', 
    link: '/products' 
  },
  { 
    src: 'https://images.unsplash.com/photo-1588943211346-0908a1fb0b01?q=80&w=2574&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', 
    alt: 'Dog enjoying a meal', 
    hint: 'dog eating food', 
    link: '/products?category=Small' 
  },
];

export const collectionImages = [
    { src: 'https://meals.dogspot.in/cdn/shop/collections/Yorkshire_Terrier.jpg?v=1654688083&width=535', alt: 'Small dog breeds', category: 'Small', hint: 'small dog' },
    { src: 'https://meals.dogspot.in/cdn/shop/collections/french_bulldog.jpg?v=1654689437&width=535', alt: 'Medium dog breeds', category: 'Medium', hint: 'medium dog' },
    { src: 'https://meals.dogspot.in/cdn/shop/collections/indian-pariah.webp?v=1654795886&width=535', alt: 'Indian dog breeds', category: 'Indie Special', hint: 'indian dog' },
    { src: 'https://meals.dogspot.in/cdn/shop/collections/Golden_Retriever_Dog_Food.jpg?v=1654690881&width=535', alt: 'Large dog breeds', category: 'Large', hint: 'large dog' },
    { src: 'https://meals.dogspot.in/cdn/shop/collections/Newfoundland_DogSpot_Meals.jpg?v=1654796533&width=535', alt: 'Giant dog breeds', category: 'Giant', hint: 'giant dog' },
];

export const featuredRecipes = [
    { name: 'Chicken and Rice', image: 'https://meals.dogspot.in/cdn/shop/files/8x75_adbe5f03-7346-484b-a484-2754ef4e10fe.png?v=1683805956&width=750', hint: 'chicken rice' },
    { name: 'Fish and Rice', image: 'https://meals.dogspot.in/cdn/shop/products/WhatsAppImage2023-02-06at09.29.20.jpg?v=1676259315&width=750', hint: 'fish rice' },
    { name: 'Chicken Gravy', image: 'https://meals.dogspot.in/cdn/shop/files/Sweet_Potato.png?v=1683807761&width=750', hint: 'chicken gravy' },
    { name: 'Chicken and Sweet Potato', image: 'https://meals.dogspot.in/cdn/shop/files/Untitled_design_8.png?v=1683808421&width=750', hint: 'chicken sweet potato' },
];

export const multicolumnItems = [
    { name: 'Chicken and Rice', image: 'https://meals.dogspot.in/cdn/shop/products/8x100_8617846d-4089-4784-8056-0260ca47c3fc.png?v=1655195669&width=750', hint: 'chicken rice pack', link: '/products' },
    { name: 'Fish and Rice', image: 'https://meals.dogspot.in/cdn/shop/files/WhatsAppImage2023-02-06at09.29.20_39337146-5f34-4b09-8aa1-ca25d1c864bf.jpg?v=1710946235&width=750', hint: 'fish rice meal', link: '/products' },
    { name: 'Chicken Gravy', image: 'https://meals.dogspot.in/cdn/shop/files/Sweet_Potato.png?v=1683807761&width=750', hint: 'chicken gravy meal', link: '/products' },
    { name: 'Chicken and Sweet Potato', image: 'https://meals.dogspot.in/cdn/shop/files/Sweet_Potato.png?v=1683807761&width=750', hint: 'chicken sweet potato', hasArrow: true, link: '/products' },
];

export const customerReviews = [
  "My dog loves this food. His coat is so shiny now.",
  "This is the best dog food I have ever bought. My pupper goes absolutely wild for it! The energy boost is incredible. HIGHLY recommend!",
  "The packaging is nice and the delivery was fast.",
  "I was skeptical at first, but wow! My finicky eater cleans her bowl every single time. It's like magic. I'm telling all my friends about DogSpot Meals!",
  "It's a bit expensive, but I guess it's worth it.",
  "I've never seen my old dog act like a puppy again until we switched to this food. He's running, jumping, and so full of life. It brings tears to my eyes. Thank you, DogSpot!",
  "Good product. My dog seems to like it.",
  "Honestly, a total game-changer for my dog's digestion issues. We've tried everything, and this is the only thing that works. Plus, he gets so excited at mealtime. Worth every penny!"
];

    
